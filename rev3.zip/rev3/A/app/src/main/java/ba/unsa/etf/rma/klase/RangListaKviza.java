package ba.unsa.etf.rma.klase;

import java.util.ArrayList;

public class RangListaKviza {

    String nazivKviza;
    ArrayList<Rang> rangLista;

    public RangListaKviza(String nazivKviza, ArrayList<Rang> rangLista) {
        this.nazivKviza = nazivKviza;
        this.rangLista = rangLista;
    }

    public String getNazivKviza() {
        return nazivKviza;
    }

    public void setNazivKviza(String nazivKviza) {
        this.nazivKviza = nazivKviza;
    }

    public ArrayList<Rang> getRangLista() {
        return rangLista;
    }

    public void setRangLista(ArrayList<Rang> rangLista) {
        this.rangLista = rangLista;
    }
}
