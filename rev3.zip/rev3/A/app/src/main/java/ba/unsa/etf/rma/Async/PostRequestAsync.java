package ba.unsa.etf.rma.Async;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostRequestAsync extends AsyncTask<String, String, String> {

    @Override
    protected String doInBackground(String... strings) {
        String urlString = strings[0]; // URL to call
        String data = strings[1]; //data to post
        String method = strings[2];
        Log.d("PRA", data);
        OutputStream out = null;
        try {
            URL url = new URL(urlString);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod(method);
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/josn");

            Log.w("PRA", "OutputStream before");
            try (OutputStream os = urlConnection.getOutputStream()) {
                byte[] input = data.getBytes("utf-8");
                os.write(input, 0, input.length);
            } catch (IOException e) {
                Log.w("PRA IOe OS", e.getMessage());
            }
            Log.w("PRA", "OutputStream after");

            int code = urlConnection.getResponseCode();
            InputStream odgovor = urlConnection.getInputStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                String r = response.toString();
                return r.substring(83, 104);
                //Log.d("ODGOVOR", response.toString());
            } catch (IOException e) {
                Log.w("PRA IOe IS", e.getMessage());
            }
        } catch (Exception e) {
            Log.w("PRA IOe", e.getMessage());
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        Log.w("PRA x", "PRA executed and finalized");
    }
}
