package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

import ba.unsa.etf.rma.Adapter.GridViewAdapter;
import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DetailFrag extends Fragment {

    ArrayList<Kviz> kvizovi;
    //Kategorija kategorija;

    GridView gridKvizovi;
    GridViewAdapter gridViewAdapter;

    View tileView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //kategorija = (Kategorija) getArguments().getSerializable("kategorija");
        kvizovi = (ArrayList<Kviz>) getArguments().getSerializable("kvizovi");
        gridKvizovi = getView().findViewById(R.id.gridKvizovi);

        if (getContext() != null) gridViewAdapter = new GridViewAdapter(getContext(), kvizovi);
        gridKvizovi.setAdapter(gridViewAdapter);

        gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (gridKvizovi.getCount() != 1) {
                    if (position != kvizovi.size() - 1) {
                        Intent intent = new Intent(getContext(), IgrajKvizAkt.class);
                        intent.putExtra("kvizPosition", position);
                        startActivity(intent);
                    }
                }
            }
        });

        gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getContext(), DodajKvizAkt.class);
                intent.putExtra("kvizPosition", position);
                startActivity(intent);
                return true;
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        /*kvizovi.clear();
        kvizovi.add(new Kviz("Dodaj kviz", new ArrayList<Pitanje>(), new Kategorija()));
        gridViewAdapter.notifyDataSetChanged();*/
    }
}
