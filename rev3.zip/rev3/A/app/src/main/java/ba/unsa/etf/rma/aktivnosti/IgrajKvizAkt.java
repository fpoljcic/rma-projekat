package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Objects;

import ba.unsa.etf.rma.Data.Data;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity {

    int kvizPosition;
    Kviz kviz;

    InformacijeFrag inf;
    PitanjeFrag pf;
    public static FrameLayout pita;

    ArrayList<Pitanje> pitanja;
    ArrayList<String> informejsn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        pitanja = new ArrayList<>();
        informejsn = new ArrayList<>();

        kvizPosition = Objects.requireNonNull(getIntent().getExtras()).getInt("kvizPosition");
        kviz = Data.getInstance().kvizovi.get(kvizPosition);
        pitanja.addAll(kviz.getPitanja());

        String naziv = kviz.getNaziv();

        ArrayList<Pitanje> pitanja = kviz.getPitanja();

        String brojt = "0";
        String brojp = String.valueOf(pitanja.size());
        String procenat = "0";

        Bundle bundle = new Bundle();
        bundle.putString("Naziv", naziv);
        bundle.putString("BrojT", brojt);
        bundle.putString("BrojP", brojp);
        bundle.putString("PT", procenat);

        Bundle bundle1 = new Bundle();
        bundle1.putSerializable("kviz", kviz);
        bundle1.putSerializable("Naziv", naziv);

        FragmentManager fm = getSupportFragmentManager();
        pita = findViewById(R.id.PitanjePlace);

        if (pita != null) {
            pf = new PitanjeFrag();
            pf.setArguments(bundle1);

            fm.beginTransaction().replace(R.id.PitanjePlace, pf).commit();
        }

        FrameLayout informacije = findViewById(R.id.InformacijePlace);
        if (informacije != null) {
            inf = new InformacijeFrag();
            inf.setArguments(bundle);
            fm.beginTransaction().replace(R.id.InformacijePlace, inf).commit();
        }
    }

    public void endAkt() {
        setResult(RESULT_OK);
        finish();
    }
}
