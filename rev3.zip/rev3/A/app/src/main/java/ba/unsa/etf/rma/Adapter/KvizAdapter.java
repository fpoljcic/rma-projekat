package ba.unsa.etf.rma.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import com.maltaisn.icondialog.IconHelper;

import java.util.ArrayList;

public class KvizAdapter extends ArrayAdapter {

    int resource;
    Context context;

    IconHelper iconHelper;

    public KvizAdapter(Context context, int resource, ArrayList<Kviz> kvizovi) {
        super(context, resource, kvizovi);
        this.resource = resource;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(resource, parent, false);
        }

        final Kviz kviz = (Kviz) getItem(position);

        final ImageView imageView = convertView.findViewById(R.id.kvizIcon);
        TextView textView = convertView.findViewById(R.id.kvizName);

        if(kviz.getKategorija().getId() == null || kviz.getKategorija().getId().trim().equals("")) {
            Glide.with(context).load(R.drawable.ic_launcher_background).into(imageView);
        } else {
            iconHelper = IconHelper.getInstance(context);
            iconHelper.addLoadCallback(new IconHelper.LoadCallback() {
                @Override
                public void onDataLoaded() {
                    imageView.setImageDrawable(iconHelper.getIcon(Integer.parseInt(kviz.getKategorija().getId())).getDrawable(context));
                }
            });
        }
        textView.setText(kviz.getNaziv());

        return convertView;
    }
}
