package ba.unsa.etf.rma.Data;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import java.util.ArrayList;

public class Data {

    public ArrayList<Kategorija> kategorije;
    public ArrayList<Kviz> kvizovi;
    public ArrayList<Pitanje> pitanja;

    private static Data instance;

    private Data() {
        kategorije = new ArrayList<>();
        kvizovi = new ArrayList<>();
        pitanja = new ArrayList<>();
    }

    public static Data getInstance() {
        if (instance == null) {
            instance = new Data();
        }
        return instance;
    }
}
