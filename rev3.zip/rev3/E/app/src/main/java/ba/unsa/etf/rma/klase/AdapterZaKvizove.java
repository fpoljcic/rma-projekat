package ba.unsa.etf.rma.klase;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;

public class AdapterZaKvizove extends ArrayAdapter<Kviz> {

    private Context context;
    private List<Kviz> list = new ArrayList<>();

    public AdapterZaKvizove(@NonNull Context context, int resource, @NonNull List<Kviz> objects) {
        super(context, resource, objects);
        this.context = context;
        list = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.list_item_kviz, parent, false);
        }

        Kviz trenutniKviz = list.get(position);

        IconView image = (IconView) listItem.findViewById(R.id.idKategorije);


        if(position == list.size() - 1) {
            image.setImageResource(R.drawable.add_icon);
       // } else if(trenutniKviz.getKategorija().equals(new Kategorija("Svi", null))) {
         //   image.setImageResource(R.drawable.bluecircle1);
        } else if(trenutniKviz.getKategorija() == null) {
            trenutniKviz.setKategorija(new Kategorija("Svi", "54"));
        } else {
            image.setIcon(Integer.parseInt(trenutniKviz.getKategorija().getId()));
        }
        TextView naziv = (TextView) listItem.findViewById(R.id.nazivKviza);
        naziv.setText(trenutniKviz.getNaziv());

        return listItem;
    }

}
