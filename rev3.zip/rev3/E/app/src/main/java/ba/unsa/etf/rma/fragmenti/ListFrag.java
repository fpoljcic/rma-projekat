package ba.unsa.etf.rma.fragmenti;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;


public class ListFrag extends Fragment {

    private ListView listView;
    private ArrayList<String> kategorije = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private OnItemClick oic;

    public ListFrag() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_list, container, false);
        listView = (ListView) v.findViewById(R.id.listaKategorija);
        return v;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments().containsKey("kategorije")) {
            ArrayList<Kategorija> a = getArguments().getParcelableArrayList("kategorije");
            for (Kategorija k : a)
                kategorije.add(k.getNaziv());
            adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, kategorije);
            listView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        }
        try {
            oic = (OnItemClick) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString());
        }
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                oic.onItemClicked(position);
            }
        });
    }

    public interface OnItemClick{
        public void onItemClicked(int pos);
    }
}
