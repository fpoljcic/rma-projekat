package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.AsyncResponse;
import ba.unsa.etf.rma.klase.CustomDialog;
import ba.unsa.etf.rma.klase.Kategorija;

import static com.google.common.collect.Lists.newArrayList;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {

    public class DodavanjeKategorije extends AsyncTask<String, Void, String> {
        private Kategorija kategorija;
        public AsyncResponse delegate = null;

        public DodavanjeKategorije(Kategorija k, AsyncResponse delegate) {
            kategorija = k;
            this.delegate = delegate;
        }

        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential credentials;
            String idKategorije = null;
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                credentials = GoogleCredential.fromStream(is).createScoped(newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/rma19hajradinovicajsa31/databases/(default)/documents/Kategorije?access_token=";
                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");

                String dokument = String.format("{ \"fields\": {\"idIkonice\": {\"integerValue\": %s}, \"naziv\": {\"stringValue\":\"%s\"}}}", kategorija.getId(), kategorija.getNaziv());


                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = dokument.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                InputStream odgovor = conn.getInputStream();
                String odg;
                try (BufferedReader br = new BufferedReader(new InputStreamReader(odgovor, "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("ODGOVOR", response.toString());
                    odg = response.toString();
                }
                JSONObject jsonObject = new JSONObject(odg);
                String[] name = jsonObject.getString("name").split("/");
                idKategorije= name[name.length-1];


            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return idKategorije;
        }

        @Override
        protected void onPostExecute(String s) {
            delegate.processFinish(s);
        }
    }


    private EditText naziv;
    private EditText ikona;
    private Button dodavanjeIkone, dodavanjeKategorije;

    private Icon[] selectedIcons;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        naziv = (EditText) findViewById(R.id.etNaziv);
        ikona = (EditText) findViewById(R.id.etIkona);
        dodavanjeIkone = (Button) findViewById(R.id.btnDodajIkonu);
        dodavanjeKategorije = (Button) findViewById(R.id.btnDodajKategoriju);

        final IconDialog iconDialog = new IconDialog();
        final ArrayList<Kategorija> postojeceKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("postojeceKategorije");
        postojeceKategorije.remove(postojeceKategorije.size() - 1); //zbog Dodaj Kategoriju


        dodavanjeIkone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        dodavanjeKategorije.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Kategorija k = new Kategorija(naziv.getText().toString(), ikona.getText().toString());
                if(naziv.getText().toString().isEmpty()) {
                    naziv.setBackgroundColor(Color.RED);
                } else if(KvizoviAkt.daLiPostojiKategorija(KvizoviAkt.kategorijeDatabase, k.getNaziv()) || k.getNaziv().equals("Svi")){
                    openDialog("Unesena kategorija već postoji!");
                } else if(ikona.getText().toString().isEmpty()) {
                    ikona.setBackgroundColor(Color.RED);
                } else {
                    naziv.setBackgroundColor(0);
                    ikona.setBackgroundColor(0);
                    final Intent intent = getIntent();
                    intent.putExtra("naziv", naziv.getText().toString());
                    intent.putExtra("ikona", ikona.getText().toString());

                    final String[] id = new String[1];
                    new DodavanjeKategorije(k, new AsyncResponse() {
                        @Override
                        public void processFinish(String output) {
                            KvizoviAkt.kategorijeDatabase.put(k, output);
                            KvizoviAkt.kategorijeApp.put(k, output);
                            id[0] = output;
                        }
                    }).execute(" ");
                    setResult(DodajKategorijuAkt.RESULT_OK, intent);
                    finish();
                }
            }
        });
    }
    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        ikona.setText(String.valueOf(icons[0].getId()));
    }

    public void openDialog(String s) {
        CustomDialog dialog = CustomDialog.newInstance(s);
        dialog.show(getSupportFragmentManager(), "dialog");
    }

}
