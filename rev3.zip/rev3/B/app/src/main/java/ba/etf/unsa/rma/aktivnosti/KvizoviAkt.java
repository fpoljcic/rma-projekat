package ba.etf.unsa.rma.aktivnosti;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.google.gson.Gson;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ba.etf.unsa.rma.R;
import ba.etf.unsa.rma.klase.Kategorija;
import ba.etf.unsa.rma.klase.KategorijaAdapter;
import ba.etf.unsa.rma.klase.Kviz;
import ba.etf.unsa.rma.klase.KvizAdapter;
import ba.etf.unsa.rma.klase.Pitanje;

/**
 * @author fhadzic1@etf.unsa.ba
 */

public class KvizoviAkt extends AppCompatActivity {

    public ArrayList<Kategorija> listaKategorija;
    public KvizAdapter adapterKviz;
    public KategorijaAdapter adapterKategorija;
    public Kategorija svi = new Kategorija("Svi", 2);

    private Spinner spinner;
    private ListView listView;
    private Kviz kviz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spPostojeceKategorije);
        listView = findViewById(R.id.lvKvizovi);

        listaKategorija = new ArrayList<Kategorija>();
        listaKategorija.add(svi);

        HttpGetKategorijaRequest get = new HttpGetKategorijaRequest();
        get.execute("https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Kategorije/?access_token=");
        adapterKategorija = new KategorijaAdapter(this, listaKategorija);
        spinner.setAdapter(adapterKategorija);

        adapterKviz = new KvizAdapter(this, R.layout.icon);
        listView.setAdapter(adapterKviz);

        Kviz dodajKviz = new Kviz("Dodaj Kviz");
        dodajKviz.setTip(1);
        dodajKviz.setKategorija(svi);
        adapterKviz.dodajKviz(dodajKviz);


        // Spinner filtracija
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                adapterKviz.filtrirajListu(adapterKategorija.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        // Otvaranje aktivnosti za Dugi KLIK NA KVIZ
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Kviz otvoreniKviz = adapterKviz.getFiltriraniKvizovi().get(position);
                if (otvoreniKviz.getTip() != 1) {
                    HttpDeleteRequest delete = new HttpDeleteRequest();
                    delete.execute("https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Kvizovi/" + otvoreniKviz.getIdFireBase() + "?access_token=");
                }
                otvoriKviz(otvoreniKviz);
                return true;
            }
        });


        // Otvaranje aktivnosti za Kratki KLIK NA KVIZ
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Kviz otvoreniKviz = adapterKviz.getFiltriraniKvizovi().get(position);
                if (otvoreniKviz.getTip() == 0) {
                    otvoriIgrajKviz(otvoreniKviz);
                }
            }
        });
    }

    private void otvoriKviz(Kviz kviz) {
        Intent kvizIntent = new Intent(this, DodajKvizAkt.class);
        Bundle b = new Bundle();
        b.putString("naziv", kviz.getNaziv());
        b.putInt("tip", kviz.getTip());
        b.putParcelableArrayList("listaPitanja", kviz.getPitanja());
        b.putParcelable("kategorija", kviz.getKategorija());
        b.putParcelableArrayList("listaKvizova", adapterKviz.getSviKvizovi());
        b.putParcelableArrayList("listaKategorija", listaKategorija);
        kvizIntent.putExtras(b);
        startActivityForResult(kvizIntent, 100);
    }

    private void otvoriIgrajKviz(Kviz kviz) {
        Intent igrajIntent = new Intent(this, IgrajKvizAkt.class);
        Bundle bdl = new Bundle();
        bdl.putString("naziv", kviz.getNaziv());
        bdl.putParcelableArrayList("ListaPitanja", kviz.getPitanja());
        igrajIntent.putExtras(bdl);
        startActivityForResult(igrajIntent, 500);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100) {
            if (data != null && data.getExtras() != null
                    && data.getExtras().containsKey("naziv")
                    && data.getExtras().containsKey("bivsiNaziv")
                    && data.getExtras().containsKey("listaKategorija")
                    && data.getExtras().containsKey("listaPitanja")
                    && data.getExtras().containsKey("tip")
                    && data.getExtras().containsKey("kategorija")) {

                String bivsiNaziv = data.getStringExtra("bivsiNaziv");
                kviz = new Kviz();
                kviz.setNaziv(data.getStringExtra("naziv"));
                kviz.setTip(data.getIntExtra("tip", 0));
                kviz.setPitanja(data.<Pitanje>getParcelableArrayListExtra("listaPitanja"));
                kviz.setKategorija(data.<Kategorija>getParcelableExtra("kategorija"));
                listaKategorija = data.getParcelableArrayListExtra("listaKategorija");

                HttpPostRequest http = new HttpPostRequest();
                http.execute();

                Collections.sort(listaKategorija);
                adapterKategorija.formatirajListu(listaKategorija);
                int i;
                for (i = 0; i < listaKategorija.size(); i++) {
                    if (listaKategorija.get(i).getNaziv().equals(kviz.getKategorija().getNaziv())) {
                        break;
                    }
                }
                spinner.setSelection(i);
                adapterKviz.addKviz(kviz, bivsiNaziv);
                adapterKviz.filtrirajListu(kviz.getKategorija());
            }
        }
    }

    public class HttpPostRequest extends AsyncTask<String, Void, String> {
        @SuppressLint("DefaultLocale")
        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential creditials;
            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                creditials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                creditials.refreshToken();
                String TOKEN = creditials.getAccessToken();
                String url = "https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Kvizovi?access_token=";

                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");

                HttpURLConnection con = (HttpURLConnection) urlObj.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);

                JSONObject jsonObject = new JSONObject();

                try {
                    JSONObject fields = new JSONObject();

                    //pitanja
                    HashMap<String, JSONObject> mapPitanja = new HashMap<>();
                    ArrayList<Pitanje> pitanja = kviz.getPitanja();
                    for (int i = 0; i < pitanja.size() - 1; i++) {
                        mapPitanja.put(String.format("%d", i), kreirajPolje("stringValue", pitanja.get(i).getIdFireBase()));
                    }
                    JSONObject atributPitanje = new JSONObject();
                    atributPitanje.put("mapValue", kreirajAtribut(mapPitanja));

                    //kviz
                    HashMap<String, JSONObject> mapKvizovi = new HashMap<>();
                    mapKvizovi.put("naziv", kreirajPolje("stringValue", kviz.getNaziv()));
                    mapKvizovi.put("nazivKategorije", kreirajPolje("stringValue", kviz.getKategorija().getNaziv()));
                    mapKvizovi.put("idKategorije", kreirajPolje("stringValue", kviz.getKategorija().getIdFireBase()));
                    mapKvizovi.put("pitanja", kreirajPolje("mapValue", kreirajAtribut(mapPitanja)));

                    JSONObject atributKviz = new JSONObject();
                    atributKviz.put("mapValue", kreirajAtribut(mapKvizovi));
                    fields.put("kviz", atributKviz);

                    // Body
                    jsonObject.put("fields", fields);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                System.out.println(jsonObject.toString());

                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = jsonObject.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = con.getResponseCode();
                System.out.println(code);

                try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    System.out.println(response.toString());

                    kviz.setIdFireBase(response.toString().substring(72, 92));

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private JSONObject kreirajAtribut(HashMap<String, JSONObject> attribut) {
            JSONObject jsonObject = new JSONObject();
            JSONObject fields = new JSONObject();
            try {
                for (Map.Entry<String, JSONObject> entry : attribut.entrySet()) {
                    fields.put(entry.getKey(), entry.getValue());
                }
                jsonObject.put("fields", fields);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject;
        }

        private JSONObject kreirajPolje(String type, Object object) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(type, object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject;
        }

    }


    public class HttpDeleteRequest extends AsyncTask<String, Void, String> {

        public static final String REQUEST_METHOD_DELETE = "DELETE";
        public static final int READ_TIMEOUT = 15000;
        public static final int CONNECTION_TIMEOUT = 15000;

        @Override
        protected String doInBackground(String... params) {
            String stringUrl = params[0];
            String result;

            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                stringUrl += credentials.getAccessToken();

                //Create a URL object holding our url
                URL myUrl = new URL(stringUrl);

                //Create a connection
                HttpURLConnection connection = (HttpURLConnection) myUrl.openConnection();
                connection.setDoInput(true);
                connection.setDoOutput(true);
                //Set methods and timeouts
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestMethod(REQUEST_METHOD_DELETE);
                connection.setReadTimeout(READ_TIMEOUT);
                connection.setConnectTimeout(CONNECTION_TIMEOUT);

                //Connect to our url
                connection.connect();

                //Create a new InputStreamReader
                InputStreamReader streamReader = new InputStreamReader(connection.getInputStream());

                //Create a new buffered reader and String Builder
                BufferedReader reader = new BufferedReader(streamReader);
                StringBuilder stringBuilder = new StringBuilder();

                //Check if the line we are reading is not null
                String inputLine;
                while ((inputLine = reader.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }

                //Close our InputStream and Buffered reader
                reader.close();
                streamReader.close();

                //Set our result equal to our stringBuilder
                result = stringBuilder.toString();

            } catch (IOException e) {
                e.printStackTrace();
                result = null;
            }

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.e("result", "" + s);
        }

    }


    public class HttpGetKategorijaRequest extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {


            String stringUrl = params[0];
            String result = "";

            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                stringUrl += credentials.getAccessToken();

                HttpGet httpGet = new HttpGet(stringUrl);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse response = httpclient.execute(httpGet);

                // StatusLine stat = response.getStatusLine();
                int status = response.getStatusLine().getStatusCode();
                if (status == 200) {
                    HttpEntity entity = response.getEntity();
                    result = EntityUtils.toString(entity);

                    //JSONObject parse
                    JSONObject jo = new JSONObject(result);
                    JSONArray document = jo.getJSONArray("documents");
                    for (int i = 0; i < document.length(); i++) {
                        JSONObject object = (JSONObject) document.get(i);
                        JSONObject fields = object.getJSONObject("fields");
                        JSONObject kategorija = fields.getJSONObject("kategorija");
                        JSONObject mapValue = kategorija.getJSONObject("mapValue");
                        JSONObject fields2 = mapValue.getJSONObject("fields");
                        // Kategorija
                        Kategorija kat = new Kategorija();

                        JSONObject nazivObject = fields2.getJSONObject("naziv");
                        kat.setNaziv(nazivObject.getString("stringValue"));

                        JSONObject idObject = fields2.getJSONObject("id");
                        kat.setId(String.valueOf(idObject.getInt("integerValue")));

                        JSONObject tipObject = fields2.getJSONObject("tip");
                        kat.setTip(tipObject.getInt("integerValue"));

                        listaKategorija.add(kat);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.e("result", "" + s);
        }

    }

}
