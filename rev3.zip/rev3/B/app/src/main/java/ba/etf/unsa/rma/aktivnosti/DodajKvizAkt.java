package ba.etf.unsa.rma.aktivnosti;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import ba.etf.unsa.rma.R;
import ba.etf.unsa.rma.klase.Kategorija;
import ba.etf.unsa.rma.klase.KategorijaAdapter;
import ba.etf.unsa.rma.klase.Kviz;
import ba.etf.unsa.rma.klase.Pitanje;
import ba.etf.unsa.rma.klase.PitanjeDodanoAdapter;
import ba.etf.unsa.rma.klase.PitanjeMoguceAdapter;

public class DodajKvizAkt extends AppCompatActivity {

    private Spinner spKategorije;
    private EditText etNaziv;
    private ListView lvDodanaPitanja;
    private ListView lvMogucaPitanja;
    private Button btnDodajKviz;
    private ArrayList<Kategorija> listaKategorija;
    private KategorijaAdapter kategorijaAdapter;
    private ArrayList<Pitanje> dodanaPitanja;
    private PitanjeDodanoAdapter dodanaAdapter;
    private ArrayList<Pitanje> mogucaPitanja = new ArrayList<Pitanje>();
    private PitanjeMoguceAdapter mogucaAdapter;
    private ArrayList<Kviz> listaKvizova;
    private String naziv = null;
    private int tip;
    private Kategorija otvorenaKategorija;
    private Kategorija dodajKategoriju = new Kategorija("Dodaj Kategoriju", 1);
    private Kategorija kategorija;
    private Pitanje pitanje;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null && bundle.containsKey("naziv") && bundle.containsKey("tip") && bundle.containsKey("listaPitanja") && bundle.containsKey("kategorija") && bundle.containsKey("listaKategorija") && bundle.containsKey("listaKvizova")) {
            naziv = bundle.getString("naziv");
            tip = bundle.getInt("tip");
            dodanaPitanja = bundle.getParcelableArrayList("listaPitanja");
            listaKvizova = bundle.getParcelableArrayList("listaKvizova");
            kategorija = bundle.getParcelable("kategorija");
            listaKategorija = bundle.getParcelableArrayList("listaKategorija");
            listaKategorija.add(listaKategorija.size(), dodajKategoriju);
        }

        spKategorije = findViewById(R.id.spKategorije);
        etNaziv = findViewById(R.id.etNaziv);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        btnDodajKviz = findViewById(R.id.btnDodajKviz);
        Button btnUveziKviz = findViewById(R.id.btnImportKviz);


        if (kategorija == null) {
            kategorija = new Kategorija();
        }

        HttpGetPitanjaRequest mPitanja = new HttpGetPitanjaRequest(mogucaPitanja);
        mPitanja.execute("https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Pitanja/?access_token=");
        Log.e("moguca size", String.format("%d",mogucaPitanja.size()));

// Adapteri

        kategorijaAdapter = new KategorijaAdapter(this, listaKategorija);
        spKategorije.setAdapter(kategorijaAdapter);

        dodanaAdapter = new PitanjeDodanoAdapter(this, R.layout.icon, dodanaPitanja);
        lvDodanaPitanja.setAdapter(dodanaAdapter);

        mogucaAdapter = new PitanjeMoguceAdapter(this, R.layout.icon, mogucaPitanja);
        lvMogucaPitanja.setAdapter(mogucaAdapter);


/*
        Log.e("moguca size", String.format("%d",mogucaPitanja.size()));
        for(int i=0; i<mogucaPitanja.size(); i++){
            mogucaAdapter.dodajMogucePitanje(mogucaPitanja.get(i));
            Log.e("naziv", mogucaPitanja.get(i).getNaziv());
        }
*/

        // Ispisi podatke o kvizu
        if (tip == 0) {
            etNaziv.setText(naziv);
            int index;

            for (index = 0; index < listaKategorija.size(); index++) {
                if (kategorija.getNaziv().equals(listaKategorija.get(index).getNaziv())) {
                    break;
                }
            }
            if (index != listaKategorija.size()) {
                spKategorije.setSelection(index);
            }
        }


        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                otvorenaKategorija = kategorijaAdapter.get(position);

                if (otvorenaKategorija.getTip() == 1) {
                    otvoriKategoriju();
                } else {
                    kategorija.setNaziv(otvorenaKategorija.getNaziv());
                    kategorija.setId(otvorenaKategorija.getId());
                    kategorija.setTip(otvorenaKategorija.getTip());
                    kategorija.setIdFireBase(otvorenaKategorija.getIdFireBase());
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

// Dodana pitanja

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (dodanaPitanja.get(position).getTip() == 0) {
                    mogucaAdapter.dodajMogucePitanje(dodanaPitanja.get(position));
                    dodanaAdapter.obrisiPitanje(dodanaPitanja.get(position));
                } else {
                    otvoriPitanje();
                }
            }
        });


// Moguca pitanja

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
             //   HttpDeletePitanjeRequest delete = new HttpDeletePitanjeRequest();
             //   delete.execute("https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Pitanja/" + mogucaPitanja.get(position).getIdFireBase() + "?access_token=");
                dodanaAdapter.postaviPitanje(mogucaPitanja.get(position));
                mogucaAdapter.obrisiPitanje(mogucaPitanja.get(position));
             //   HttpPostRequest post = new HttpPostRequest("Pitanja");
             //   post.execute();

            }
        });

        // Validacija Kviza
        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean nazivValidan = !etNaziv.getText().toString().equals("");
                if (!nazivValidan) {
                    etNaziv.setBackgroundColor(Color.RED);
                } else {

                    if (postojiKviz(etNaziv.getText().toString())) {
                        nazivValidan = false;
                        Toast.makeText(getApplicationContext(), "Postoji kviz sa istim imenom!", Toast.LENGTH_LONG).show();
                    }

                }
                boolean kategorijaValidna = (kategorija != null && kategorija.getTip() != 2);
                if (!kategorijaValidna) {
                    spKategorije.setBackgroundColor(Color.RED);
                }

                if (nazivValidan && kategorijaValidna) {
                    spremiKviz(etNaziv.getText().toString(), naziv);
                }
            }
        });


        btnUveziKviz.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Toast.makeText(DodajKvizAkt.this, "Dugi klik!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });


    }

    private void spremiKviz(String naziv, String bivsiNaziv) {

        Intent mainIntent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putString("naziv", naziv);
        bundle.putString("bivsiNaziv", bivsiNaziv);
        bundle.putInt("tip", 0);
        bundle.putParcelable("kategorija", kategorija);
        Collections.sort(listaKategorija);
        listaKategorija.remove(dodajKategoriju);
        bundle.putParcelableArrayList("listaKategorija", listaKategorija);
        bundle.putParcelableArrayList("listaPitanja", dodanaPitanja);
        mainIntent.putExtras(bundle);

        setResult(100, mainIntent);
        finish();

    }


    private void otvoriPitanje() {
        Intent pitanjeIntent = new Intent(getApplicationContext(), DodajPitanjeAkt.class);
        Bundle bdl = new Bundle();
        bdl.putParcelableArrayList("dodanaPitanja", dodanaPitanja);
        bdl.putParcelableArrayList("mogucaPitanja", mogucaAdapter.getMogucaPitanja());
        pitanjeIntent.putExtras(bdl);
        startActivityForResult(pitanjeIntent, 200);
    }

    private void otvoriKategoriju() {
        Intent kategorijaIntent = new Intent(getApplicationContext(), DodajKategorijuAkt.class);
        Bundle bdl = new Bundle();
        bdl.putParcelableArrayList("listaKategorija", listaKategorija);
        kategorijaIntent.putExtras(bdl);
        startActivityForResult(kategorijaIntent, 300);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 200) {
            if (data != null && data.getExtras() != null && data.getExtras().containsKey("novoPitanje")) {
                pitanje = (Pitanje) data.getParcelableExtra("novoPitanje");
                dodanaAdapter.postaviPitanje(pitanje);

                HttpPostRequest post = new HttpPostRequest("Pitanja");
                post.execute();
            }
        }

        if (requestCode == 300) {
            if (data != null && data.getExtras() != null && data.getExtras().containsKey("naziv") && data.getExtras().containsKey("ikona")) {
                kategorija.setNaziv(data.getStringExtra("naziv"));
                kategorija.setId(data.getStringExtra("ikona"));
                kategorija.setTip(0);
                listaKategorija.add(kategorija);
                Collections.sort(listaKategorija);
                kategorijaAdapter.notifyDataSetChanged();

                //Pozicija u spinneru nakon dodavanja nove kategorije u listu
                int position;
                for (position = 0; position < listaKategorija.size(); position++) {
                    if (kategorija.getNaziv().equals(listaKategorija.get(position).getNaziv())) {
                        break;
                    }
                }
                spKategorije.setSelection(position);

                HttpPostRequest post = new HttpPostRequest("Kategorije");
                post.execute();

            }
        }

    }


    public class HttpDeletePitanjeRequest extends AsyncTask<String, Void, String> {

        public static final String REQUEST_METHOD_DELETE = "DELETE";
        public static final int READ_TIMEOUT = 15000;
        public static final int CONNECTION_TIMEOUT = 15000;

        @Override
        protected String doInBackground(String... params) {
            String stringUrl = params[0];
            String result;

            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                stringUrl += credentials.getAccessToken();

                //Create a URL object holding our url
                URL myUrl = new URL(stringUrl);

                //Create a connection
                HttpURLConnection connection = (HttpURLConnection) myUrl.openConnection();
                connection.setDoInput(true);
                connection.setDoOutput(true);
                //Set methods and timeouts
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestMethod(REQUEST_METHOD_DELETE);
                connection.setReadTimeout(READ_TIMEOUT);
                connection.setConnectTimeout(CONNECTION_TIMEOUT);

                //Connect to our url
                connection.connect();

                //Create a new InputStreamReader
                InputStreamReader streamReader = new InputStreamReader(connection.getInputStream());

                //Create a new buffered reader and String Builder
                BufferedReader reader = new BufferedReader(streamReader);
                StringBuilder stringBuilder = new StringBuilder();

                //Check if the line we are reading is not null
                String inputLine;
                while ((inputLine = reader.readLine()) != null) {
                    stringBuilder.append(inputLine);
                }

                //Close our InputStream and Buffered reader
                reader.close();
                streamReader.close();

                //Set our result equal to our stringBuilder
                result = stringBuilder.toString();

            } catch (IOException e) {
                e.printStackTrace();
                result = null;
            }

            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.e("result", "" + s);
        }

    }


    public class HttpGetPitanjaRequest extends AsyncTask<String, Void, String> {

        ArrayList<Pitanje> pitanja;

        public HttpGetPitanjaRequest(ArrayList<Pitanje> pitanja) {
            this.pitanja = pitanja;
        }

        @Override
        protected String doInBackground(String... params) {


            String stringUrl = params[0];
            String result = "";

            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                stringUrl += credentials.getAccessToken();

                HttpGet httpGet = new HttpGet(stringUrl);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse response = httpclient.execute(httpGet);

                // StatusLine stat = response.getStatusLine();
                int status = response.getStatusLine().getStatusCode();
                if (status == 200) {
                    HttpEntity entity = response.getEntity();
                    result = EntityUtils.toString(entity);

                    //JSONObject parse
                    JSONObject jo = new JSONObject(result);
                    JSONArray document = jo.getJSONArray("documents");
                    for (int i = 0; i < document.length(); i++) {
                        JSONObject object = (JSONObject) document.get(i);
                        JSONObject fields = object.getJSONObject("fields");
                        JSONObject pitanje = fields.getJSONObject("pitanje");
                        JSONObject mapValue = pitanje.getJSONObject("mapValue");
                        JSONObject fields2 = mapValue.getJSONObject("fields");
                        // Pitanje

                        JSONObject tipObject = fields2.getJSONObject("tip");
                        int tip = tipObject.getInt("integerValue");

                        if(tip == 1) {
                            Pitanje p = new Pitanje();
                            p.setTip(tip);

                            JSONObject nazivObject = fields2.getJSONObject("naziv");
                            p.setNaziv(nazivObject.getString("stringValue"));

                            JSONObject indexTacnogObject = fields2.getJSONObject("indexTacnog");
                            int indexTacnog = indexTacnogObject.getInt("integerValue");

                            JSONObject odgovoriObject = fields2.getJSONObject("odgovori");
                            JSONObject mapValue1 = odgovoriObject.getJSONObject("mapValue");
                            JSONObject fields3 = mapValue1.getJSONObject("fields");

                            ArrayList<String> odgovori = new ArrayList<>();
                            for (int j = 0; j < fields3.length(); j++) {
                                @SuppressLint("DefaultLocale") JSONObject odg = fields3.getJSONObject(String.format("%d", j));
                                odgovori.add(odg.getString("stringValue"));
                                if(j==indexTacnog){
                                    p.setTacan(odg.getString("stringValue"));
                                }
                            }

                            p.setOdgovori(odgovori);
                            mogucaPitanja.add(p);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.e("result", "" + s);
        }

    }


    public class HttpPostRequest extends AsyncTask<String, Void, String> {

        String kolekcija = null;

        public HttpPostRequest(String kolekcija) {
            this.kolekcija = kolekcija;
        }

        @SuppressLint("DefaultLocale")
        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential creditials;
            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                creditials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                creditials.refreshToken();
                String TOKEN = creditials.getAccessToken();
                String url = null;

                // Url
                if (kolekcija.equals("Kategorije")) {
                    url = "https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Kategorije?access_token=";
                } else if (kolekcija.equals("Pitanja")) {
                    url = "https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Pitanja?access_token=";
                }

                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");

                HttpURLConnection con = (HttpURLConnection) urlObj.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);

                JSONObject jsonObject = new JSONObject();

                try {
                    JSONObject fields = new JSONObject();

                    if (kolekcija.equals("Kategorije")) {
                        // Kategorija
                        HashMap<String, JSONObject> mapKategorija = new HashMap<>();
                        mapKategorija.put("id", kreirajPolje("integerValue", kategorija.getId()));
                        mapKategorija.put("naziv", kreirajPolje("stringValue", kategorija.getNaziv()));
                        mapKategorija.put("tip", kreirajPolje("integerValue", kategorija.getTip()));

                        JSONObject atributKategorija = new JSONObject();
                        atributKategorija.put("mapValue", kreirajAtribut(mapKategorija));
                        fields.put("kategorija", atributKategorija);
                    } else if (kolekcija.equals("Pitanja")) {
                        //Odgovori
                        HashMap<String, JSONObject> mapOdgovori = new HashMap<>();
                        ArrayList<String> odgovori = pitanje.getOdgovori();
                        for (int i = 0; i < odgovori.size(); i++) {
                            mapOdgovori.put(String.format("%d", i), kreirajPolje("stringValue", odgovori.get(i)));
                        }
                        JSONObject atributOdgovor = new JSONObject();
                        atributOdgovor.put("mapValue", kreirajAtribut(mapOdgovori));

                        //Pitanje
                        HashMap<String, JSONObject> mapPitanje = new HashMap<>();
                        mapPitanje.put("naziv", kreirajPolje("stringValue", pitanje.getNaziv()));
                        mapPitanje.put("indexTacnog", kreirajPolje("integerValue", pitanje.getIndexTacnog()));
                        mapPitanje.put("tip", kreirajPolje("integerValue", pitanje.getTip()));
                        mapPitanje.put("odgovori", kreirajPolje("mapValue", kreirajAtribut(mapOdgovori)));

                        JSONObject atributPitanje = new JSONObject();
                        atributPitanje.put("mapValue", kreirajAtribut(mapPitanje));
                        fields.put("pitanje", atributPitanje);
                    }
                    // Body
                    jsonObject.put("fields", fields);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                System.out.println(jsonObject.toString());

                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = jsonObject.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = con.getResponseCode();
                System.out.println(code);

                try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    System.out.println(response.toString());

                    if (kolekcija.equals("Kategorije")) {
                        kategorija.setIdFireBase(response.toString().substring(75, 95));

                    } else if (kolekcija.equals("Pitanja")) {
                        pitanje.setIdFireBase(response.toString().substring(72, 92));
                    }

                    //HttpPostidFireBaseRequest id = new HttpPostidFireBaseRequest(kolekcija);
                    //id.execute();

                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private JSONObject kreirajAtribut(HashMap<String, JSONObject> attribut) {
            JSONObject jsonObject = new JSONObject();
            JSONObject fields = new JSONObject();
            try {
                for (Map.Entry<String, JSONObject> entry : attribut.entrySet()) {
                    fields.put(entry.getKey(), entry.getValue());
                }
                jsonObject.put("fields", fields);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject;
        }

        private JSONObject kreirajPolje(String type, Object object) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(type, object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject;
        }

        public void setKolekcija(String kolekcija) {
            this.kolekcija = kolekcija;
        }

    }



    // Zabrana dodavanja novog kviza, ako već postoji kviz sa istim imenom
    private boolean postojiKviz(String noviNaziv) {
        int i;

        if (tip == 1) {

            for (i = 0; i < listaKvizova.size(); i++) {
                if (noviNaziv.equals(listaKvizova.get(i).getNaziv())) {
                    break;
                }
            }
            if (i < listaKvizova.size()) {
                etNaziv.setBackgroundColor(Color.RED);
                etNaziv.setText("");
                return true;
            }
        } else if (naziv != null && tip == 0) {
            for (i = 0; i < listaKvizova.size(); i++) {
                if (noviNaziv.equals(listaKvizova.get(i).getNaziv()) && (!noviNaziv.equals(naziv))) {
                    break;
                }
            }
            if (i < listaKvizova.size()) {
                etNaziv.setBackgroundColor(Color.RED);
                etNaziv.setText("");
                return true;
            }
        }

        return false;
    }

}













/*
    public class HttpPostidFireBaseRequest extends AsyncTask<String, Void, String> {

        String kolekcija = null;

        public HttpPostidFireBaseRequest(String kolekcija) {
            this.kolekcija = kolekcija;
        }

        @SuppressLint("DefaultLocale")
        @Override
        protected String doInBackground(String... strings) {
            GoogleCredential creditials;
            try {
                InputStream tajnaStream = getResources().openRawResource(R.raw.secret);
                creditials = GoogleCredential.fromStream(tajnaStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                creditials.refreshToken();
                String TOKEN = creditials.getAccessToken();
                String url = null;

                // Url
                if (kolekcija.equals("Kategorije")) {
                    url = "https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Kategorije/" + kategorija.getIdFireBase() + "?access_token=";
                } else if (kolekcija.equals("Pitanja")) {
                    url = "https://firestore.googleapis.com/v1/projects/spirala3-f5787/databases/(default)/documents/Pitanja?access_token=";
                }

                URL urlObj = new URL(url + URLEncoder.encode(TOKEN, "UTF-8"));
                HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setRequestProperty("Accept", "application/json");

                JSONObject jsonObject = new JSONObject();

                try {
                    JSONObject fields = new JSONObject();
                    if (kolekcija.equals("Kategorije")) {
                        // Kategorija
                        HashMap<String, JSONObject> mapKategorija = new HashMap<>();
                        mapKategorija.put("idFireBase", kreirajPolje("stringValue", kategorija.getIdFireBase()));
                        JSONObject atributKategorija = new JSONObject();
                        atributKategorija.put("mapValue", kreirajAtribut(mapKategorija));
                        fields.put("kategorija", atributKategorija);
                    } else if (kolekcija.equals("Pitanja")) {
/*                        //Odgovori
                        HashMap<String, JSONObject> mapOdgovori = new HashMap<>();
                        ArrayList<String> odgovori = pitanje.getOdgovori();
                        for (int i = 0; i < odgovori.size(); i++) {
                            mapOdgovori.put(String.format("%d", i), kreirajPolje("stringValue", odgovori.get(i)));
                        }
                        JSONObject atributOdgovor = new JSONObject();
                        atributOdgovor.put("mapValue", kreirajAtribut(mapOdgovori));

                        //Pitanje
                        HashMap<String, JSONObject> mapPitanje = new HashMap<>();
                        mapPitanje.put("naziv", kreirajPolje("stringValue", pitanje.getNaziv()));
                        mapPitanje.put("indexTacnog", kreirajPolje("integerValue", pitanje.getIndexTacnog()));
                        mapPitanje.put("tip", kreirajPolje("integerValue", pitanje.getTip()));
                        mapPitanje.put("odgovori", kreirajPolje("mapValue", kreirajAtribut(mapOdgovori)));

                        JSONObject atributPitanje = new JSONObject();
                        atributPitanje.put("mapValue", kreirajAtribut(mapPitanje));
                        fields.put("pitanje", atributPitanje); *
                    }

                    // Body
                    jsonObject.put("fields", fields);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                System.out.println(jsonObject.toString());

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonObject.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int code = conn.getResponseCode();
                System.out.println(code);

                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    System.out.println(response.toString());


                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        private JSONObject kreirajAtribut(HashMap<String, JSONObject> attribut) {
            JSONObject jsonObject = new JSONObject();
            JSONObject fields = new JSONObject();
            try {
                for (Map.Entry<String, JSONObject> entry : attribut.entrySet()) {
                    fields.put(entry.getKey(), entry.getValue());
                }
                jsonObject.put("fields", fields);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject;
        }

        private JSONObject kreirajPolje(String type, Object object) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(type, object);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return jsonObject;
        }

        public void setKolekcija(String kolekcija) {
            this.kolekcija = kolekcija;
        }

    }
*/

