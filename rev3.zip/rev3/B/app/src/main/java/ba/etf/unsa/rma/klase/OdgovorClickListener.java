package ba.etf.unsa.rma.klase;

public interface OdgovorClickListener {

    void clicked(boolean tacan);
}
