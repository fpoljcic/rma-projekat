package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Random;

public class Pitanje implements Parcelable {

    private String naziv = null;
    private String tekstPitanja = null;
    private ArrayList<String> odgovori = null;
    private String tacan = null;

    public Pitanje(String naziv){
        this.naziv = naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getNaziv() {
        return naziv;
    }

    public ArrayList<String> getOdgovori() {
        return odgovori;
    }

    public String getTacan() {
        return tacan;
    }

    public String getTekstPitanja() {
        return tekstPitanja;
    }

    public void setOdgovori(ArrayList<String> odgovori) {
        this.odgovori = odgovori;
    }

    public void setTacan(String tacan) {
        this.tacan = tacan;
    }

    public void setTekstPitanja(String tekstPitanja) {
        this.tekstPitanja = tekstPitanja;
    }

    public ArrayList<String> dajRandomOdgovore() {
        ArrayList<String> randomOdgovori = new ArrayList<String>(odgovori);
        Collections.shuffle(randomOdgovori, new Random());
        return  randomOdgovori;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(naziv);
        parcel.writeString(tekstPitanja);
        parcel.writeStringList(odgovori);
        parcel.writeString(tacan);
    }

    public static final Parcelable.Creator CREATOR= new Parcelable.Creator(){
        public Pitanje createFromParcel(Parcel in) {
            return new Pitanje(in);
        }

        @Override
        public Pitanje[] newArray(int i) {
            return new Pitanje[i];
        }
    };
    public Pitanje(Parcel in){
        naziv = in.readString();
        tekstPitanja = in.readString();
        in.readStringList(odgovori);
        tacan = in.readString();

    }
}
