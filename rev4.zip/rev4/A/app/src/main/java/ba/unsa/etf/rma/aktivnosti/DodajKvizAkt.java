package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.MainActivity;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DodanoPitanjeAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.KategorijaAdapter;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.KvizAdapter;
import ba.unsa.etf.rma.klase.MogucePitanjeAdapter;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKvizAkt extends Activity {

    private Spinner kat = null;
    private ArrayList<Kviz> kvizovi = new ArrayList<Kviz>();
    private ArrayList<Kategorija> kategorije = new ArrayList<Kategorija>();
    private KategorijaAdapter kategorijaadapter = null;
    private Kategorija kategorija = null;
    private String naziv = null;
    private EditText tenaziv = null;
    private ArrayList<Pitanje> dodanapitanja = new ArrayList<Pitanje>();
    private DodanoPitanjeAdapter izabranapitanjaad = null;
    private ListView dpit = null;
    private ArrayList<Pitanje> mogucapitanja = new ArrayList<Pitanje>();
    private MogucePitanjeAdapter mogucapitanjaad = null;
    private ListView mpit = null;
    private ArrayList<Pitanje> pitanja = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dodaj_kviz);

        kategorije = getIntent().getParcelableArrayListExtra("kategorije");
        kvizovi = getIntent().getParcelableArrayListExtra("kvizovi");

        kategorije.add(new Kategorija("Dodaj kategoriju"));

        kat = findViewById(R.id.spKategorije);

        kategorijaadapter = new KategorijaAdapter(this, kategorije);
        kat.setAdapter(kategorijaadapter);
        kat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Kategorija k = (Kategorija) parent.getItemAtPosition(position);
                String nkate = k.getNaziv();

                if(nkate.equalsIgnoreCase("Dodaj kategoriju")){
                    Intent dk = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    dk.putParcelableArrayListExtra("kategorije",(ArrayList) kategorije);
                    DodajKvizAkt.this.startActivity(dk);
                } else {
                    kategorija = k;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        tenaziv = findViewById(R.id.etNaziv);
        naziv = tenaziv.getText().toString();

        boolean nijeZauzet = true;
        for(int i = 0; i < kvizovi.size(); i++){
            if(kvizovi.get(i).getNaziv().equals(naziv)){
                nijeZauzet = false;
            }
        }

        if(!nijeZauzet){
            naziv = "";
        }

        dpit = findViewById(R.id.lvDodanaPitanja);
        dodanapitanja = new ArrayList<Pitanje>();
        dodanapitanja.add(new Pitanje("Dodaj pitanje"));

        izabranapitanjaad = new DodanoPitanjeAdapter(this, dodanapitanja);
        dpit.setAdapter(izabranapitanjaad);

        dpit.setClickable(true);
        dpit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Pitanje p = (Pitanje) dpit.getItemAtPosition(position);
                String nkviz = p.getNaziv();
                if (nkviz.equalsIgnoreCase("Dodaj pitanje")) {
                    Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                    intent.putParcelableArrayListExtra("pitanja",(ArrayList) pitanja);
                    startActivity(intent);
                }
            }
        });

        mpit = findViewById(R.id.lvMogucaPitanja);
        mogucapitanja = new ArrayList<Pitanje>();

        mogucapitanjaad = new MogucePitanjeAdapter(this, mogucapitanja);
        mpit.setAdapter(mogucapitanjaad);

        mpit.setClickable(true);
        mpit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

            }
        });

        Button button = findViewById(R.id.btnDodajKviz);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Kviz novi = new Kviz(naziv);
                novi.setKategorija(kategorija);
                novi.setPitanja(dodanapitanja);
                kvizovi.add(novi);
                finish();
            }
        });

    }
}
