package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;

import java.io.InputStream;
import java.io.Serializable;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.baza.QueryExec;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangLista;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.RangIgrac;
import ba.unsa.etf.rma.klase.RangPodaci;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.QueryAsync;
import ba.unsa.etf.rma.taskovi.TaskExec;
import ba.unsa.etf.rma.utility.IReceiverAction;
import ba.unsa.etf.rma.utility.InternetStateReceiver;

public class IgrajKvizAkt extends AppCompatActivity implements Serializable, InformacijeFrag.OnFragmentInteractionListener,
        RangLista.OnFragmentInteractionListenerRang, QueryAsync.QueryExecutor, AsyncPostPatch.OnUploaded,
        IReceiverAction {

    private FragmentManager fm;
    private RangPodaci rl=new RangPodaci();
    private Kviz k=new Kviz();
    private InternetStateReceiver receiver=new InternetStateReceiver();
    private IntentFilter filter = new IntentFilter();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_ak);
        Intent intent=getIntent();
        Bundle b=intent.getExtras();
        filter.addAction(android.net.ConnectivityManager.CONNECTIVITY_ACTION);
        receiver.setAction(this);

          k=new Kviz();
        if(b!=null) k=(Kviz)b.get("kviz");
        if(k!=null) rl.setNaziv(k.getNaziv());
       if(InternetStateReceiver.ismConnected()) new QueryAsync(getInputStrm(),this).execute(rl);
       else if(rl.getNaziv()!=null) {
             RangPodaci rp= DataAccessLayer.getInstance().dajRangListu(rl.getNaziv());
             if(rp!=null) rl=rp;
       }


        fm=getSupportFragmentManager();
        FrameLayout informacijePlace=(FrameLayout) findViewById(R.id.informacijePlace);
        FrameLayout pitanjePlace=(FrameLayout) findViewById(R.id.pitanjePlace);
        InformacijeFrag informacijeFrag=(InformacijeFrag) fm.findFragmentById(R.id.informacijePlace);
        if(informacijeFrag==null){
            informacijeFrag=new InformacijeFrag();
            Bundle args=new Bundle();
            args.putString("naziv", k.getNaziv());
            args.putInt("ukupno", k.getPitanja().size());
            args.putSerializable("mlistener",this);
            informacijeFrag.setArguments(args);
            fm.beginTransaction().replace(R.id.informacijePlace,informacijeFrag).commit();
        }

        PitanjeFrag pitanjeFrag=(PitanjeFrag) fm.findFragmentById(R.id.pitanjePlace);
        if(pitanjeFrag==null){
            pitanjeFrag=new PitanjeFrag();
            Bundle args=new Bundle();
            args.putParcelable("kviz", k);
            args.putSerializable("mlistener",informacijeFrag);
            pitanjeFrag.setArguments(args);
            fm.beginTransaction().replace(R.id.pitanjePlace,pitanjeFrag).commit();
        }

    }



    @Override
    public void onFragmentInteractionRang(Uri uri) {

    }

    @Override
    public void onQueryExecuted(String vrijednost) {
        rl= TaskExec.parseRang(vrijednost);
        if(!DataAccessLayer.getInstance().checkIfCorrect(rl)){
            RangPodaci rp=null;
            if( rl.getNaziv()!=null) rp= DataAccessLayer.getInstance().dajRangListu(rl.getNaziv());
            if(rp!=null) rl=rp;
        }
        rl.setNaziv(k.getNaziv());
    }


    private InputStream getInputStrm(){

        return getResources().openRawResource(R.raw.secret);
    }

    @Override
    public void onFragmentInteraction(String uri, double procenat) {


            rl.addIgrac(new RangIgrac(uri,procenat));
            if(InternetStateReceiver.ismConnected()) {
                if (!rl.getIdBaza().equals(""))
                    new AsyncPostPatch(getInputStrm(), "PATCH", this).execute(rl);
                else new AsyncPostPatch(getInputStrm(), "POST", this).execute(rl);
            }
            else {

                if (!rl.getIdBaza().equals(""))  QueryExec.azurirajRangListu(rl);
                else QueryExec.pisiUBazuRang(rl);
                proceedToRangLista();
            }


    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

        proceedToRangLista();
    }

    private void proceedToRangLista() {
        RangLista lista  =new RangLista();
        Bundle args=new Bundle();
        args.putSerializable("igraci",rl);
        lista.setArguments(args);
        fm.beginTransaction().replace(R.id.pitanjePlace,lista).commit();
    }

    @Override
    public void enable() {

    }

    @Override
    public void disable() {

    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver,filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }
}
