package ba.unsa.etf.rma.fragmenti;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.io.Serializable;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.utility.SharedViewModel;

public class InformacijeFrag extends Fragment implements PitanjeFrag.OnFragmentInteractionListenerPitanje,Serializable {

    private static final String ARG_PARAM1 = "param1";

    private String naziv="";
    private int brojUkupno=0, ukupno=0,brojTacnih=0;
    private TextView  infNazivKviza, infBrojTacnihPitanja, infBrojPreostalihPitanja, infProcenatTacni;
    private Button btnKraj;
    private double procenatTacnih;


    private OnFragmentInteractionListener mListener;

    public InformacijeFrag() {

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_informacije, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments()!=null){
            if(getArguments().containsKey("ukupno")) brojUkupno=getArguments().getInt("ukupno");
            if(getArguments().containsKey("naziv")) naziv=getArguments().getString("naziv");
            if (getArguments().containsKey("mlistener")) mListener = (OnFragmentInteractionListener) getArguments().get("mlistener");
        }
        ukupno=brojUkupno;
        infNazivKviza=(TextView) getView().findViewById(R.id.infNazivKviza);
        infBrojTacnihPitanja=(TextView) getView().findViewById(R.id.infBrojTacnihPitanja);
        infBrojPreostalihPitanja=(TextView) getView().findViewById(R.id.infBrojPreostalihPitanja);
        infProcenatTacni=(TextView)getView().findViewById(R.id.infProcenatTacni);
        btnKraj=(Button)getView().findViewById(R.id.btnKraj);
        show();
        final SharedViewModel model= ViewModelProviders.of(getActivity()).get(SharedViewModel.class);
        model.getInfo().observe(this, new Observer() {
            @Override
            public void onChanged(@Nullable Object o) {
                brojTacnih=(int)o;
            if(brojUkupno>0) brojUkupno--;
                show();
            }
        });

        btnKraj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in= new Intent();
                getActivity().setResult(5,in);
                getActivity().finish();
            }
        });

    }

    private void show(){

        infNazivKviza.setText(naziv);
        infBrojTacnihPitanja.setText(brojTacnih+"");
        infBrojPreostalihPitanja.setText((brojUkupno==0?0:brojUkupno-1)+"");
        procenatTacnih=(ukupno-brojUkupno==0)?0:((double)brojTacnih/(ukupno-brojUkupno)) * 100;
        infProcenatTacni.setText(procenatTacnih+"");
    }


    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onFragmentInteractionPitanje(String ime) {
        mListener.onFragmentInteraction(ime, procenatTacnih);

    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(String uri, double procenat);
    }
}
