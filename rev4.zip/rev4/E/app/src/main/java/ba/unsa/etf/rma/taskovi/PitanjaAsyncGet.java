package ba.unsa.etf.rma.taskovi;

import android.os.AsyncTask;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.utility.InputStreamReader;

public class PitanjaAsyncGet extends AsyncTask<ArrayList<String>, Integer, ArrayList<Pitanje>> {
    GoogleCredential credentials;
    InputStream stream;
    private Boolean sva;
    PitanjaAsyncGet.OnPitanjeLoadDone pozivatelj;
    public PitanjaAsyncGet(InputStream is, PitanjaAsyncGet.OnPitanjeLoadDone pozivatelj, boolean sva) {
        this.stream = is;
        this.pozivatelj=pozivatelj;
        this.sva=sva;
    }

    public interface OnPitanjeLoadDone{
        void onPitanjaLoaded(ArrayList<Pitanje> pitanja);
    }



    @Override
    protected ArrayList<Pitanje> doInBackground(ArrayList<String>... arrayLists) {
        ArrayList<Pitanje> pitanja=new ArrayList<>();
        try {
            credentials= GoogleCredential.fromStream(stream).createScoped(Lists.<String>newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            HttpURLConnection conn2=getConnection();
            InputStream ins= new BufferedInputStream(conn2.getInputStream());
            String rezultat= InputStreamReader.convertStreamToString(ins);
            pitanja=parsePitanja(rezultat,arrayLists[0]);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

        return pitanja;
    }

    private ArrayList<Pitanje> parsePitanja(String rezultat, ArrayList<String> pitanjaIds) throws JSONException {


        String projectName="projects/spirala-a85a9/databases/(default)/documents/Pitanja/";
        JSONObject jsonObject=new JSONObject(rezultat);
        JSONArray dokumenti=jsonObject.getJSONArray("documents");
        ArrayList<Pitanje> pitanja=new ArrayList<>();
        for(int i=0;i<dokumenti.length();i++) {

            JSONObject pitanjeBaza = dokumenti.getJSONObject(i);
            String idBaza = pitanjeBaza.getString("name");
            JSONObject field = pitanjeBaza.getJSONObject("fields");
            String id = idBaza.replace(projectName, "");
            if (!sva && pitanjaIds.contains(id)) {
                pitanja.add(parsePitanje(field,id));
            }
            else if(sva) pitanja.add(parsePitanje(field,id));

        }

         return pitanja;


    }

    private HttpURLConnection getConnection() throws IOException {

        credentials.refreshToken();
        String TOKEN=credentials.getAccessToken();

        String url="https://firestore.googleapis.com/v1/projects/spirala-a85a9/databases/(default)/documents/Pitanja?access_token=";
        URL urlObj=new  URL(url+ URLEncoder.encode(TOKEN, "UTF-8"));
        HttpURLConnection conn=(HttpURLConnection)urlObj.openConnection();
        conn.setDoInput(true);
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-Type","application/json");
        conn.setRequestProperty("Accept", "application/json");

        return  conn;

    }

    @Override
    protected void onPostExecute(ArrayList<Pitanje> pitanjes) {
        super.onPostExecute(pitanjes);
        pozivatelj.onPitanjaLoaded(pitanjes);
    }

    private Pitanje parsePitanje(JSONObject field, String id) throws JSONException {

        Pitanje pitanje=new Pitanje();
        JSONObject objectNaziv = field.getJSONObject("naziv");
        pitanje.setNaziv(objectNaziv.getString("stringValue"));
        JSONObject objectIkonica = field.getJSONObject("indexTacnog");
        JSONObject objectArr=field.getJSONObject("odgovori").getJSONObject("arrayValue");
        JSONArray objectArray=objectArr.getJSONArray("values");
        ArrayList<String> odgovori=new ArrayList<>();
        for(int j=0;j<objectArray.length();j++){
            JSONObject odgItem=objectArray.getJSONObject(j);
            String odgovor=odgItem.getString("stringValue");
            odgovori.add(odgovor);
        }
        pitanje.setOdgovori(odgovori);
        pitanje.setId(id);
        pitanje.setTacan(odgovori.get(objectIkonica.getInt("integerValue")));

        return pitanje;
    }
}
