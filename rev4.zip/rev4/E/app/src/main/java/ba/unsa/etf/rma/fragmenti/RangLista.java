package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.RangAdapter;
import ba.unsa.etf.rma.klase.RangIgrac;
import ba.unsa.etf.rma.klase.RangPodaci;

public class RangLista extends Fragment {

    private ListView rangLista;
    private ArrayList<RangIgrac> igraci=new ArrayList<>();
    private RangAdapter adapter;
    private RangPodaci podaci=new RangPodaci();

    private OnFragmentInteractionListenerRang mListener;

    public RangLista() {

    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }


    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getArguments()!=null){
            RangPodaci rl;
            if (getArguments().containsKey("igraci")){
                rl= (RangPodaci) getArguments().get("igraci");
              if(rl!=null)  igraci=rl.getIgraci();
            }
        }
        rangLista = (ListView)getView().findViewById(R.id.rangListaView);
        adapter=new RangAdapter(getContext(),igraci);
        rangLista.setAdapter(adapter);
        adapter.notifyDataSetChanged();


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        return inflater.inflate(R.layout.fragment_rang_lista, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListenerRang) {
            mListener = (OnFragmentInteractionListenerRang) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListenerRang {
        // TODO: Update argument type and name
        void onFragmentInteractionRang(Uri uri);
    }
}
