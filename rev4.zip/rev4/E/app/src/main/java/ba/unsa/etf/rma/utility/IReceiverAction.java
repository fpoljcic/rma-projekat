package ba.unsa.etf.rma.utility;

public interface IReceiverAction {
    void enable();
    void disable();
}
