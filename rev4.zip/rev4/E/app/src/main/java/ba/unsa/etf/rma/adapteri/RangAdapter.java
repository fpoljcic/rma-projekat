package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.RangIgrac;


public class RangAdapter extends BaseAdapter {
    private ArrayList<RangIgrac> podaci;
    private LayoutInflater mInflater;

//fixme ako ovo ne radi, onda dodati context
    public RangAdapter(Context c, ArrayList<RangIgrac> podaci) {
        this.podaci = podaci;
        mInflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return podaci.size();
    }
    public void setData(ArrayList<RangIgrac> data){
        podaci=data;
    }

    @Override
    public Object getItem(int position) {
        return podaci.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v=mInflater.inflate(R.layout.rang_item,null);
        TextView pozicija=(TextView)v.findViewById(R.id.pozicijaView);
        TextView ime=(TextView)v.findViewById(R.id.imeText);
        TextView procenatTacni=(TextView)v.findViewById(R.id.procenatTacnihTxt);
        ime.setTextColor(v.getResources().getColor(R.color.grelight));
        procenatTacni.setTextColor(v.getResources().getColor(R.color.zelena));
        ime.setText(podaci.get(position).getIme());
        pozicija.setText(podaci.get(position).getPozicija()+"");
        procenatTacni.setText(podaci.get(position).getProcenatTacnih()+"");
        return v;
    }
}
