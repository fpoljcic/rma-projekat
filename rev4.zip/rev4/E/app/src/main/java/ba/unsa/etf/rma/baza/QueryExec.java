package ba.unsa.etf.rma.baza;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.UUID;

import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangIgrac;
import ba.unsa.etf.rma.klase.RangPodaci;

public class QueryExec {

    private static DataAccessLayer dao=DataAccessLayer.getInstance();



    public static ArrayList<Kviz> getKvizovi(SQLiteOpenHelper helper){

        String[] koloneRezulat = new String[]{ BazaHelper.ID, BazaHelper.NAZIV, BazaHelper.KATEGORIJA_ID};
        String[] koloneRezulatPitanja = new String[]{ BazaHelper.ID_PITANJA};

        SQLiteDatabase db = helper.getWritableDatabase();

        Cursor cursor = db.query(BazaHelper.KVIZ_TABLE,
                koloneRezulat, null,
                null, null, null, null);

        ArrayList<Kviz> kvizovi= new ArrayList<>();
        int INDEX_KOLONE_naziv = cursor.getColumnIndexOrThrow(BazaHelper.NAZIV);
        int INDEX_KOLONE_id = cursor.getColumnIndexOrThrow(BazaHelper.ID);
        int INDEX_KOLONE_kategorija = cursor.getColumnIndexOrThrow(BazaHelper.KATEGORIJA_ID);

        while(cursor.moveToNext()){
            Kviz k=new Kviz();
            k.setId(cursor.getString(INDEX_KOLONE_id));
            k.setNaziv(cursor.getString(INDEX_KOLONE_naziv));
            Kategorija kat=dao.dajKategoriju(cursor.getString(INDEX_KOLONE_kategorija));
            if(kat==null) kat=Kategorija.kategorijaSvi();
            k.setKategorija(kat);
            ArrayList<Pitanje> pitanja=new ArrayList<>();
            String where = BazaHelper.ID_KVIZA + " = "+ "'"+k.getIdBaza()+"'";
            Cursor cursor2 = db.query(BazaHelper.PITANJE_KVIZA_TABLE,
                    koloneRezulatPitanja, where,
                    null, null, null, null);
            int INDEX_KOLONE_id_pitanja = cursor2.getColumnIndexOrThrow(BazaHelper.ID_PITANJA);
            while(cursor2.moveToNext()){
                Pitanje p=dao.dajPitanjeizId(cursor2.getString(INDEX_KOLONE_id_pitanja));
                if(p!=null) pitanja.add(p);

            }
            k.setPitanja(pitanja);

            kvizovi.add(k);

        }
        cursor.close();
        return kvizovi;

    }

    public static ArrayList<Kategorija> getKategorija(SQLiteOpenHelper helper){
        String[] koloneRezulat = new String[]{ BazaHelper.ID, BazaHelper.NAZIV, BazaHelper.ID_IKONICE};

        SQLiteDatabase db = helper.getWritableDatabase();

        Cursor cursor = db.query(BazaHelper.KATEGORIJA_TABLE,
                koloneRezulat, null,
                null, null, null, null);

        ArrayList<Kategorija> kategorije= new ArrayList<>();
        int INDEX_KOLONE_naziv = cursor.getColumnIndexOrThrow(BazaHelper.NAZIV);
        int INDEX_KOLONE_id = cursor.getColumnIndexOrThrow(BazaHelper.ID);
        int INDEX_KOLONE_ikonica = cursor.getColumnIndexOrThrow(BazaHelper.ID_IKONICE);
        while(cursor.moveToNext()){
            Kategorija kategorija=new Kategorija();
            kategorija.setId(cursor.getString(INDEX_KOLONE_ikonica));
            kategorija.setNaziv(cursor.getString(INDEX_KOLONE_naziv));
            kategorija.setIdBaza(cursor.getString(INDEX_KOLONE_id));

            kategorije.add(kategorija);
        }

        cursor.close();

        return kategorije;
    }

    public static ArrayList<Pitanje> getPitanja(SQLiteOpenHelper helper){

        String[] koloneRezulat = new String[]{ BazaHelper.ID, BazaHelper.NAZIV, BazaHelper.TACAN};
        String[] koloneRezulatOdgovori = new String[]{ BazaHelper.ODGOVOR_TEKST};


        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cursor = db.query(BazaHelper.PITANJE_TABLE,
                koloneRezulat, null,
                null, null, null, null);

        ArrayList<Pitanje> pitanja= new ArrayList<>();
        int INDEX_KOLONE_naziv = cursor.getColumnIndexOrThrow(BazaHelper.NAZIV);
        int INDEX_KOLONE_id = cursor.getColumnIndexOrThrow(BazaHelper.ID);
        int INDEX_KOLONE_tacan = cursor.getColumnIndexOrThrow(BazaHelper.TACAN);

        while(cursor.moveToNext()){
            Pitanje pitanje=new Pitanje();
            pitanje.setId(cursor.getString(INDEX_KOLONE_id));
            pitanje.setNaziv(cursor.getString(INDEX_KOLONE_naziv));
            pitanje.setTacan(cursor.getString(INDEX_KOLONE_tacan));
            ArrayList<String> odgovori=new ArrayList<>();
            String where = BazaHelper.ID_PITANJA + " = "+ "'"+pitanje.getIdBaza()+"'";
            Cursor cursor2 = db.query(BazaHelper.ODGOVOR_TABLE,
                    koloneRezulatOdgovori, where,
                    null, null, null, null);
            int INDEX_KOLONE_odgovor = cursor2.getColumnIndexOrThrow(BazaHelper.ODGOVOR_TEKST);
            while(cursor2.moveToNext()){
                String odg=(cursor2.getString(INDEX_KOLONE_odgovor));
                if(odg!=null) odgovori.add(odg);

            }
            pitanje.setOdgovori(odgovori);

            pitanja.add(pitanje);

        }
        cursor.close();
        return pitanja;

    }

    public static void pisiUBazuKategorije(BazaHelper helper){

        ArrayList<Kategorija> kategorije=dao.getKategorijaZaUpis();
        for(Kategorija kategorija: kategorije)
        {
            pisiUBazuKategoriju(kategorija,helper);
        }
    }

    public static void pisiUBazuPitanja(BazaHelper helper){

        ArrayList<Pitanje> pitanja=dao.getPitanjaZaUpis();
        for(Pitanje pitanje: pitanja)
        {
            pisiUBazuPitanje(pitanje,helper);
        }
    }

    public static void pisiUBazuOdgovore(BazaHelper helper) {

        ArrayList<Pitanje> pitanja = dao.getPitanjaZaUpis();
        SQLiteDatabase db = helper.getWritableDatabase();
        for (Pitanje pitanje : pitanja) {
            for (String odgovor : pitanje.getOdgovori()) {

                ContentValues noveVrijednosti = new ContentValues();
                noveVrijednosti.put(BazaHelper.ODGOVOR_TEKST, odgovor);
                noveVrijednosti.put(BazaHelper.ID_PITANJA, pitanje.getIdBaza());
                db.insert(BazaHelper.ODGOVOR_TABLE, null, noveVrijednosti);
            }
        }
    }

    public static void pisiUBazuKvizove(BazaHelper helper){

        ArrayList<Kviz> kvizovi=dao.getSviKvizovi();
        SQLiteDatabase db = helper.getWritableDatabase();
        db.execSQL("DELETE FROM "+ BazaHelper.KVIZ_TABLE+";");
        db.execSQL("DELETE FROM "+ BazaHelper.PITANJE_KVIZA_TABLE+";");
        for(Kviz kviz: kvizovi)
        {
            if(kviz.getNaziv().equals(Kviz.dodajNovi().getNaziv())) continue;
            ContentValues noveVrijednosti = new ContentValues();
            noveVrijednosti.put(BazaHelper.ID, kviz.getIdBaza());
            noveVrijednosti.put(BazaHelper.NAZIV,kviz.getNaziv());
            noveVrijednosti.put(BazaHelper.KATEGORIJA_ID,kviz.getKategorija().getIdBaza());
            db.insert(BazaHelper.KVIZ_TABLE,null,noveVrijednosti);

        }        pisiUBazuPitanjaKviza(helper);

    }

    public static void pisiUBazuPitanjaKviza(BazaHelper helper) {


        ArrayList<Kviz> kvizovi = dao.getSviKvizovi();
        SQLiteDatabase db = helper.getWritableDatabase();
        for (Kviz kviz : kvizovi) {
            if(kviz.getNaziv().equals(Kviz.dodajNovi().getNaziv())) continue;
            ArrayList<Pitanje> pitanja=kviz.getPitanja();
            for (Pitanje p : pitanja) {

                ContentValues noveVrijednosti = new ContentValues();
                noveVrijednosti.put(BazaHelper.ID_KVIZA, kviz.getIdBaza());
                noveVrijednosti.put(BazaHelper.ID_PITANJA, p.getIdBaza());
                db.insert(BazaHelper.PITANJE_KVIZA_TABLE, null, noveVrijednosti);

            }
        }
    }

    public static void pisiUBazuKategoriju(Kategorija kategorija, SQLiteOpenHelper helper){
        SQLiteDatabase db = helper.getWritableDatabase();

            ContentValues noveVrijednosti = new ContentValues();
            noveVrijednosti.put(BazaHelper.ID, kategorija.getIdBaza());
            noveVrijednosti.put(BazaHelper.NAZIV,kategorija.getNaziv());
            noveVrijednosti.put(BazaHelper.ID_IKONICE,kategorija.getId());
            db.insert(BazaHelper.KATEGORIJA_TABLE,null,noveVrijednosti);

    }

    public static void pisiUBazuPitanje(Pitanje pitanje, SQLiteOpenHelper helper){

        SQLiteDatabase db = helper.getWritableDatabase();

            ContentValues noveVrijednosti = new ContentValues();
            noveVrijednosti.put(BazaHelper.ID, pitanje.getIdBaza());
            noveVrijednosti.put(BazaHelper.NAZIV,pitanje.getNaziv());
            noveVrijednosti.put(BazaHelper.TACAN, pitanje.getTacan());
            db.insert(BazaHelper.PITANJE_TABLE,null,noveVrijednosti);

        }


    public static void pisiUBazuRangListe(BazaHelper helper){


        ArrayList<RangPodaci> podaci=dao.getRangPodaciLokalna();

        SQLiteDatabase db = helper.getWritableDatabase();

        db.execSQL("DELETE FROM "+ BazaHelper.RANG_IGRAC_TABLE+";");
        db.execSQL("DELETE FROM "+ BazaHelper.RANG_PODACI_TABLE+";");

        for(RangPodaci rp: podaci)
        {
            ContentValues noveVrijednosti = new ContentValues();
            noveVrijednosti.put(BazaHelper.ID, rp.getIdBaza());
            noveVrijednosti.put(BazaHelper.ID_KVIZA,dao.dajIdIzNazivaKviza(rp.getNaziv()));

            db.insert(BazaHelper.RANG_PODACI_TABLE,null,noveVrijednosti);
        }
        pisiUBazuRangIgrace(helper);

    }

    public static void pisiUBazuRang(RangPodaci rp){

        SQLiteOpenHelper helper= KvizoviAkt.getHelper();
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues noveVrijednosti = new ContentValues();

        String source = rp.getNaziv();
        byte[] bytes = new byte[0];
        UUID uuid;
        try {
            bytes = source.getBytes("UTF-8");
            uuid= UUID.nameUUIDFromBytes(bytes);
            //ovo promijenila
            rp.setId(uuid.toString().replaceAll("-","").replaceAll("/?",""));
        } catch (UnsupportedEncodingException e) {
            rp.setId(rp.getNaziv().replaceAll("/?", ""));
            e.printStackTrace();
        }

        noveVrijednosti.put(BazaHelper.ID, rp.getIdBaza());
        noveVrijednosti.put(BazaHelper.ID_KVIZA,dao.dajIdIzNazivaKviza(rp.getNaziv()));
        try
        {
            db.insertOrThrow(BazaHelper.RANG_PODACI_TABLE,null,noveVrijednosti);
            azurirajRangListu(rp);

        }
        catch (SQLException e)
        {
        }
    }

    private static void pisiUBazuRangIgrace(BazaHelper helper) {
        ArrayList<RangPodaci> podaci=dao.getRangPodaciLokalna();

        SQLiteDatabase db = helper.getWritableDatabase();

        for(RangPodaci rp: podaci)
        {
            for(RangIgrac rIgrac: rp.getIgraci()) {

                ContentValues noveVrijednosti = new ContentValues();
                noveVrijednosti.put(BazaHelper.NAZIV, rIgrac.getIme());
                noveVrijednosti.put(BazaHelper.POZICIJA_IGRACA,rIgrac.getPozicija());
                noveVrijednosti.put(BazaHelper.PROCENAT_TACNIH,rIgrac.getProcenatTacnih());
                noveVrijednosti.put(BazaHelper.ID_RANG_PODACI,rp.getIdBaza());
                db.insert(BazaHelper.RANG_IGRAC_TABLE, null, noveVrijednosti);
            }
        }
    }

    public static ArrayList<RangPodaci> getRangPodaci(SQLiteOpenHelper helper){


        String[] koloneRezulat = new String[]{ BazaHelper.ID, BazaHelper.ID_KVIZA};
        String[] koloneRezulatIgraci = new String[]{ BazaHelper.NAZIV, BazaHelper.POZICIJA_IGRACA, BazaHelper.PROCENAT_TACNIH};


        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor cursor = db.query(BazaHelper.RANG_PODACI_TABLE,
                koloneRezulat, null,
                null, null, null, null);

        ArrayList<RangPodaci> rangPodaci= new ArrayList<>();
        int INDEX_KOLONE_naziv = cursor.getColumnIndexOrThrow(BazaHelper.ID_KVIZA);
        int INDEX_KOLONE_id = cursor.getColumnIndexOrThrow(BazaHelper.ID);

        while(cursor.moveToNext()){
            RangPodaci rp=new RangPodaci();
            rp.setId(cursor.getString(INDEX_KOLONE_id));
            rp.setNaziv(dao.dajNazivIzIdKviza(cursor.getString(INDEX_KOLONE_naziv)));
            ArrayList<RangIgrac> igraci=new ArrayList<>();
            String where = BazaHelper.ID_RANG_PODACI + " = "+ "'"+rp.getIdBaza()+"'";
            Cursor cursor2 = db.query(BazaHelper.RANG_IGRAC_TABLE,
                    koloneRezulatIgraci, where,
                    null, null, null, null);
            int INDEX_KOLONE_ime = cursor2.getColumnIndexOrThrow(BazaHelper.NAZIV);
            int INDEX_KOLONE_pozicija = cursor2.getColumnIndexOrThrow(BazaHelper.POZICIJA_IGRACA);
            int INDEX_KOLONE_procenat = cursor2.getColumnIndexOrThrow(BazaHelper.PROCENAT_TACNIH);
            while(cursor2.moveToNext()){
                RangIgrac rangIgrac=new RangIgrac();
                String ime=(cursor2.getString(INDEX_KOLONE_ime));
                Integer pozicija=(cursor2.getInt(INDEX_KOLONE_pozicija));
                Double procenat=(cursor2.getDouble(INDEX_KOLONE_procenat));
                if(ime!=null) {
                    rangIgrac.setPozicija(pozicija);
                    rangIgrac.setIme(ime);
                    rangIgrac.setProcenatTacnih(procenat);
                }
                igraci.add(rangIgrac);

            }
            rp.setIgraci(igraci);
            rangPodaci.add(rp);

        }
        cursor.close();
        return rangPodaci;
    }

    public static void azurirajRangListu(RangPodaci rp){
        SQLiteOpenHelper helper= KvizoviAkt.getHelper();
        SQLiteDatabase db = helper.getWritableDatabase();
        DataAccessLayer.getInstance().dodajRangLokalno(rp);

        db.execSQL("DELETE FROM "+ BazaHelper.RANG_IGRAC_TABLE+ " where "+ BazaHelper.ID_RANG_PODACI + "="+"'"+rp.getIdBaza()+"';");

        for(RangIgrac rIgrac: rp.getIgraci()) {

            ContentValues noveVrijednosti = new ContentValues();
            noveVrijednosti.put(BazaHelper.NAZIV, rIgrac.getIme());
            noveVrijednosti.put(BazaHelper.POZICIJA_IGRACA,rIgrac.getPozicija());
            noveVrijednosti.put(BazaHelper.PROCENAT_TACNIH,rIgrac.getProcenatTacnih());
            noveVrijednosti.put(BazaHelper.ID_RANG_PODACI,rp.getIdBaza());
            db.insert(BazaHelper.RANG_IGRAC_TABLE, null, noveVrijednosti);
        }

    }

}
