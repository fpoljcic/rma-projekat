package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.UUID;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.PitanjaAsyncGet;
import ba.unsa.etf.rma.taskovi.QueryAsync;
import ba.unsa.etf.rma.utility.IReceiverAction;
import ba.unsa.etf.rma.utility.InternetStateReceiver;

public class DodajPitanjeAkt extends AppCompatActivity implements QueryAsync.QueryExecutor, PitanjaAsyncGet.OnPitanjeLoadDone, IReceiverAction, DataAccessLayer.DataLoader, AsyncPostPatch.OnUploaded {
    private  ListView lvOdgovori;
    private Button btnDodajOgovor,btnDodajTacan,btnDodajPitanje;
    private TextView etOdgovor,etNaziv;
    private String tacan;
    private int pos=-1;
    private boolean zahtjevProcessing=false, loaded=false;
    private DataAccessLayer dao=DataAccessLayer.getInstance();
    private ArrayList<String> odgovori=new ArrayList<>();
    private ArrayList<Pitanje> pitanja=new ArrayList<>();
    private Pitanje pitanje=new Pitanje("naziv");
    static Integer idPitanja=2;
    private  PitanjaAsyncGet asyncGet;
    private InternetStateReceiver receiver=new InternetStateReceiver();
    private IntentFilter filter = new IntentFilter();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        filter.addAction(android.net.ConnectivityManager.CONNECTIVITY_ACTION);
        receiver.setAction(this);


        final Intent in = getIntent();
        Bundle b = in.getExtras();
        etOdgovor=(TextView)findViewById(R.id.etOdgovor);
        lvOdgovori = (ListView) findViewById(R.id.lvOdgovori);
        etNaziv=(TextView)findViewById(R.id.etNaziv);
        btnDodajOgovor = (Button) findViewById(R.id.btnDodajOdgovor);
        btnDodajTacan = (Button) findViewById(R.id.btnDodajTacan);







        final ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, R.layout.item_list,R.id.textViewList, odgovori){

            @Override
            public View getView(int position,  View convertView, ViewGroup parent) {
                View v= super.getView(position, convertView, parent);

              if(position==pos){
                  v.setBackgroundColor(getResources().getColor(R.color.colorGreen));
              }
              else v.setBackgroundColor(getResources().getColor(R.color.background_color));

              return v;
            }
        };

        lvOdgovori.setAdapter(adapter);
        btnDodajPitanje = (Button) findViewById(R.id.btnDodajPitanje);
        if(!InternetStateReceiver.ismConnected()) disable();



        if (b != null) {
            pitanje=(Pitanje)b.get("pitanje");
            Kviz a=(Kviz) b.get("kviz");
           if(a!=null){ pitanja=a.getPitanja();
               System.out.println("nesto nije ok");}

        }
        btnDodajOgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String odg=etOdgovor.getText().toString();

                if(odg.length()>0 && !odgovori.contains(odg)) {odgovori.add(odg);etOdgovor.setText("");}

                adapter.notifyDataSetChanged();
            }
        });
        lvOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==pos){
                    tacan=null;
                    btnDodajTacan.setEnabled(true);
                    pos=-1;
                }
                odgovori.remove(position);
                adapter.notifyDataSetChanged();
            }
        });
        btnDodajTacan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String odg = etOdgovor.getText().toString();
                if (odg.length() > 0 && !odgovori.contains(odg)) {
                    tacan = odg;
                    pos = odgovori.size();
                    odgovori.add(tacan);
                    etOdgovor.setText("");
                    adapter.notifyDataSetChanged();
                }

                if (tacan != null) {
                    btnDodajTacan.setEnabled(false);
                    lvOdgovori.setBackgroundColor(getResources().getColor(R.color.background_color));
                }
            }
        });

        etNaziv.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if(etNaziv.getText().length()>0 && !odgovori.contains(etOdgovor.getText().toString()))
                    etNaziv.setBackgroundColor(getResources().getColor(R.color.background_color));
                return false;
            }
        });


        btnDodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             if(zahtjevProcessing) return;
                if(odgovori.size()==0 || tacan==null || etNaziv.getText().length()==0 ||nalaziSePitanje(etNaziv.getText().toString()) ) {

                    if (odgovori.size() == 0 || tacan == null) {
                        lvOdgovori.setBackgroundColor(getResources().getColor(R.color.colorRed));
                    }
                    if (etNaziv.getText().length() == 0 ||nalaziSePitanje(etNaziv.getText().toString())) {
                        etNaziv.setBackgroundColor(getResources().getColor(R.color.colorRed));
                        alertDialog("Uneseno pitanje već postoji!");

                    }
                    return;
                }
                etNaziv.setBackgroundColor(getResources().getColor(R.color.background_color));
                lvOdgovori.setBackgroundColor(getResources().getColor(R.color.background_color));
                pitanje.setNaziv(etNaziv.getText().toString());
                pitanje.setOdgovori(odgovori);
                String source = pitanje.getNaziv() + pitanje.getTacan();
                byte[] bytes = new byte[0];
                UUID uuid;
                try {
                    bytes = source.getBytes("UTF-8");
                    uuid= UUID.nameUUIDFromBytes(bytes);
                    //ovo promijenila
                    pitanje.setId(uuid.toString().replaceAll("-","").replaceAll("/?",""));
                } catch (UnsupportedEncodingException e) {
                   pitanje.setId(idPitanja.toString());
                   idPitanja++;
                   e.printStackTrace();
                }

                pitanje.setTekstPitanja(pitanje.getNaziv());
                pitanje.setTacan(tacan);

                zahtjevProcessing=true;
                new QueryAsync(getInputStrm(),getQueryExec()).execute(pitanje);


            }
        });
    }

    private boolean nalaziSePitanje(String m){
        ArrayList<Pitanje> pitanjaLokalno=dao.getPitanja();
        for(Pitanje a: pitanjaLokalno){
            if (a.getNaziv().equals(m))return true;
        }
        return false;
    }
    private InputStream getInputStrm(){

        return getResources().openRawResource(R.raw.secret);
    }
    private QueryAsync.QueryExecutor getQueryExec(){
        return this;
    }


    @Override
    public void onQueryExecuted(String rezultat) {
        zahtjevProcessing=false;
        Boolean vrijednost=parseQuery(rezultat);
        if(vrijednost){
            etNaziv.setBackgroundColor(getResources().getColor(R.color.colorRed));
            asyncGet= new PitanjaAsyncGet(getInputStrm(),this,true);
            asyncGet.execute(new ArrayList<String>());
            alertDialog("Uneseno pitanje već postoji!");
        }
        else {
            Intent intent=new Intent();
            intent.putExtra("pitanje", pitanje);
            setResult(3, intent);
            finish();
        }
    }

    private Boolean parseQuery(String rezultat) {
        if(rezultat.contains(pitanje.getNaziv())) return true;
        return false;

    }
    private void alertDialog(String text) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setMessage(text);
        dialog.setTitle("Upozorenje");
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                    }
                });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    @Override
    public void onPitanjaLoaded(ArrayList<Pitanje> pitanja) {
        loaded=true;
        dao.setPitanja(pitanja);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(loaded) {
            Intent intent=new Intent();
            setResult(5,intent);
            Log.d("loaded3", "onBackPressed: ");
            finish();
        }
        else if(asyncGet!=null && !asyncGet.isCancelled())   {
              asyncGet.cancel(true);
              setResult(9);
               finish();
          }

    }

    @Override
    public void enable() {
        btnDodajPitanje.setEnabled(true);
        dao.setPozivatelj(this);
        dao.getKategorijeBaza(getInputStrm());
        dao.getKvizoviBaza(getInputStrm(), Kategorija.kategorijaSvi());
        dao.getPitanjaBaza(getInputStrm());
        dao.getRangPodaciFire(getInputStrm());

        toast("Uređaj spojen na internet, u toku osvježavanje lokalne baze i firebase-a(rang). Molimo sačekajte obavijesti o zavšetku.");

    }

    private void toast(CharSequence text) {
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(getBaseContext(), text, duration);
        toast.show();
    }

    @Override
    public void disable() {
        toast("Uređaj odspojen s interneta, onemoguceno dodavanje pitanja");

        btnDodajPitanje.setEnabled(false);
    }
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver,filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }

    @Override
    public void onDataLoaded(String type) {
        if (type.equals("rang")) {
            dao.setSviKvizovi(dao.getKvizovi());
            new AsyncPostPatch(getInputStrm(), "PATCH",  this).execute(dao.getRangPodaciLokalna().toArray(new IParselableBaza[dao.getRangPodaciLokalna().size()]));

            dao.ucitajUBazu(KvizoviAkt.getHelper());
            toast("Gotovo!");
        }
    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

    }
}
