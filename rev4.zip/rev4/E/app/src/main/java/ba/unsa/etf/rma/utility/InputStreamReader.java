package ba.unsa.etf.rma.utility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;

public class InputStreamReader {

    public static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new
                java.io.InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
        } finally {
            try {
                is.close();
            } catch (IOException e) {
            }
        }
        return sb.toString();
    }
}
