package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.UUID;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.taskovi.AsyncPostPatch;
import ba.unsa.etf.rma.taskovi.IParselableBaza;
import ba.unsa.etf.rma.taskovi.KategorijaGet;
import ba.unsa.etf.rma.taskovi.QueryAsync;
import ba.unsa.etf.rma.utility.IReceiverAction;
import ba.unsa.etf.rma.utility.InternetStateReceiver;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback, QueryAsync.QueryExecutor, KategorijaGet.OnKategorijaLoaded,
        IReceiverAction, DataAccessLayer.DataLoader, AsyncPostPatch.OnUploaded {
    private TextView etNaziv, etIkona;
    private Button btnDodajIkonu, btnDodajKategoriju;
    static Integer idKategorijeBaza=1;
    private com.maltaisn.icondialog.Icon[] selectedIcons;
    private Kategorija novaKat;
    private boolean zahtjevProcessing=false;
    private DataAccessLayer dao=DataAccessLayer.getInstance();
    private InternetStateReceiver receiver=new InternetStateReceiver();
    private IntentFilter filter = new IntentFilter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        filter.addAction(android.net.ConnectivityManager.CONNECTIVITY_ACTION);
        receiver.setAction(this);


        final IconDialog iconDialog = new IconDialog();
         etNaziv=(TextView) findViewById(R.id.etNaziv);
         etIkona=(TextView) findViewById(R.id.etIkona);
         btnDodajIkonu=(Button)findViewById(R.id.btnDodajIkonu);
         btnDodajKategoriju=(Button) findViewById(R.id.btnDodajKategoriju);


        if(!InternetStateReceiver.ismConnected()) disable();

        etNaziv.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if(etNaziv.getText().length()>=0 && !dao.nalaziSeKategorija(etNaziv.getText().toString()))
                    etNaziv.setBackgroundColor(getResources().getColor(R.color.background_color));

                return false;
            }
        });

         btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 iconDialog.setSelectedIcons(selectedIcons);
                 iconDialog.show(getSupportFragmentManager(), "icon_dialog");
             }
         });
         btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if(zahtjevProcessing) return;
                 String naziv=etNaziv.getText().toString();
                 String id=etIkona.getText().toString();
                 if(id.length()==0 || dao.nalaziSeKategorija(naziv) || naziv.length()==0) {
                   if(id.length()==0)  etIkona.setBackgroundColor(getResources().getColor(R.color.colorRed));

                   if(dao.nalaziSeKategorija(naziv) || naziv.length() == 0) {
                         etNaziv.setBackgroundColor(getResources().getColor(R.color.colorRed));
                       alertDialog("Unesena kategorija već postoji!");
                     }
                 }
                 else{
                     novaKat =new Kategorija(naziv,id);

                     String source = naziv+id;
                     byte[] bytes = new byte[0];
                     UUID uuid;
                     try {
                         bytes = source.getBytes("UTF-8");
                         uuid= UUID.nameUUIDFromBytes(bytes);
                         novaKat.setIdBaza(uuid.toString().replace("-",""));
                     } catch (UnsupportedEncodingException e) {

                         novaKat.setIdBaza(idKategorijeBaza.toString());
                         idKategorijeBaza++;
                         e.printStackTrace();
                     }
                     zahtjevProcessing=true;
                     new QueryAsync(getInputStrm(),getQueryExec()).execute(novaKat);

                 }
             }
         });

    }


    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        etIkona.setText(icons[0].getId()+"");
        if(etIkona.getText().length()>=0)
            etIkona.setBackgroundColor(getResources().getColor(R.color.background_color));

    }

    @Override
    public void onQueryExecuted(String rezultat) {
        Boolean vrijednost=parseQuery(rezultat);
        zahtjevProcessing=false;
        if(vrijednost){
            etNaziv.setBackgroundColor(getResources().getColor(R.color.colorRed));
            new KategorijaGet(getInputStrm(),this).execute("sve");
            alertDialog("Unesena kategorija već postoji!");

        }
        else {
            Intent intent=new Intent();
            intent.putExtra("kategorija",novaKat);
            setResult(4,intent);
            finish();
        }
    }

    private InputStream getInputStrm(){

        return getResources().openRawResource(R.raw.secret);
    }
    private QueryAsync.QueryExecutor getQueryExec(){
        return this;
    }

    private void alertDialog(String text) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setMessage(text);
        dialog.setTitle("Upozorenje");
        dialog.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,
                                        int which) {
                    }
                });
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    private Boolean parseQuery(String rezultat) {
        if(rezultat.contains(novaKat.getNaziv())) return true;
        return false;

    }

    @Override
    public void onDone(ArrayList<Kategorija> kategorijas) {
        dao.setKategorije(kategorijas);
    }

    @Override
    public void enable() {
        btnDodajKategoriju.setEnabled(true);
        toast("Uređaj spojen na internet, u toku osvježavanje lokalne baze i firebase-a(rang). Molimo sačekajte obavijesti o zavšetku.");


        dao.getKategorijeBaza(getInputStrm());
        dao.setPozivatelj(this);
        dao.getKvizoviBaza(getInputStrm(), Kategorija.kategorijaSvi());
        dao.getPitanjaBaza(getInputStrm());
        dao.getRangPodaciFire(getInputStrm());


    }

    @Override
    public void disable() {
        toast("Uređaj odspojen s interneta,onemoguceno dodavanje kategorije");

        btnDodajKategoriju.setEnabled(false);
    }
    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver,filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }

    @Override
    public void onDataLoaded(String type) {
        if (type.equals("rang")) {
            dao.setSviKvizovi(dao.getKvizovi());
            new AsyncPostPatch(getInputStrm(), "PATCH",  this).execute(dao.getRangPodaciLokalna().toArray(new IParselableBaza[dao.getRangPodaciLokalna().size()]));

            dao.ucitajUBazu(KvizoviAkt.getHelper());
            toast("Gotovo!");
        }
    }

    private void toast(CharSequence text){
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(getBaseContext(), text, duration);
        toast.show();

    }

    @Override
    public void onUploadDone(IParselableBaza object, String id) {

    }
}
