package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

import ba.unsa.etf.rma.taskovi.IParselableBaza;

// TODO: 4/16/2019  uklonila sam serializable provjeriti moze li sve bez 
public class Kviz implements  Pregled, Parcelable, IParselableBaza {
    private String naziv="";
    private String id="";
    private ArrayList<Pitanje> pitanja=new ArrayList<>();
    private Kategorija kategorija;
    private static Kviz dodaj=new Kviz("Dodaj kviz",null, Kategorija.kategorijaSvi());

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void dodajPitanje(Pitanje p){
        pitanja.add(p);
    }

    public String getIdBaza() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    @Override
    public String toString() {
        return  naziv;
    }


    public Kviz(String naziv) {
        this.naziv = naziv;
    }

    public Kviz(String naziv,ArrayList<Pitanje> pitanjaK, Kategorija kategorija) {
        this.pitanja=pitanjaK;
        this.naziv = naziv;
        this.kategorija = kategorija;
    }

    public ArrayList<String> getPitanjaString(){

        ArrayList<String> pitanjaStr=new ArrayList<>();
        for(Pitanje a: pitanja){
            pitanjaStr.add(a.getNaziv());
        }
        return pitanjaStr;
    }

    public Kviz() {
    }
    public static Kviz dodajNovi(){
        return dodaj;
    }

    @Override
    public boolean equals(Object obj) {
        Kviz a=(Kviz)obj;
        return a.naziv.equals(naziv);
    }

    protected Kviz(Parcel in) {
        naziv = in.readString();
        id=in.readString();
        if (in.readByte() == 0x01) {
            pitanja = new ArrayList<Pitanje>();
            in.readList(pitanja, Pitanje.class.getClassLoader());
        } else {
            pitanja = null;
        }
        kategorija = (Kategorija) in.readValue(Kategorija.class.getClassLoader());
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(naziv);
        dest.writeString(id);
        if (pitanja == null) {
            dest.writeByte((byte) (0x00));
        } else {
            dest.writeByte((byte) (0x01));
            dest.writeList(pitanja);
        }
        dest.writeValue(kategorija);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Kviz> CREATOR = new Parcelable.Creator<Kviz>() {
        @Override
        public Kviz createFromParcel(Parcel in) {
            return new Kviz(in);
        }

        @Override
        public Kviz[] newArray(int size) {
            return new Kviz[size];
        }
    };


}



