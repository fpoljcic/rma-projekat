package ba.unsa.etf.rma.fragmenti;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.GridAdapter;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.DataAccessLayer;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;

public class DetailFrag extends Fragment {

    private GridAdapter<Kviz> adapter;
    private GridView gridView;
    private DataAccessLayer dao=DataAccessLayer.getInstance();
    private int position=0;

    public DetailFrag() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        gridView=(GridView)getView().findViewById(R.id.gridKvizovi);
        if(getArguments()!=null && getArguments().containsKey("position")){
            position=getArguments().getInt("position");
        }

        adapter = new GridAdapter<Kviz>(getActivity(), promjenaKat());
        adapter.addData(Kviz.dodajNovi());
        gridView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent showDetailActivity = new Intent(getActivity(), DodajKvizAkt.class);
                if (position != promjenaKat().size() - 1) {
                    showDetailActivity.putExtra("kviz", promjenaKat().get(position));
                    showDetailActivity.putExtra("pos", position);
                }
                startActivityForResult(showDetailActivity, 2);
                return true;
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == promjenaKat().size() - 1) return;
                Intent in = new Intent(getActivity(), IgrajKvizAkt.class);
                in.putExtra("kviz", promjenaKat().get(position));
                startActivity(in);
            }
        });
    }

    private ArrayList<Kviz> promjenaKat() {
        ArrayList<Kviz> filter = new ArrayList<>();
        if( position >=dao.getKategorije().size() ||(dao.getKategorije().get(position).equals(Kategorija.kategorijaSvi()))) {
            dao.removeKviz(Kviz.dodajNovi());
            filter.addAll(dao.getSviKvizovi());
            filter.add(Kviz.dodajNovi());
            dao.addKviz(Kviz.dodajNovi());
            return filter;
        }

        dao.removeKviz(Kviz.dodajNovi());
        for (Kviz a : dao.getSviKvizovi()) {
            if (a.getKategorija().equals(dao.getKategorije().get(position))) filter.add(a);
        }
        filter.add(Kviz.dodajNovi());
        dao.addKviz(Kviz.dodajNovi());
        return filter;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data == null) return;
        adapter.setData(promjenaKat());
        adapter.notifyDataSetChanged();
    }

}
