package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;


public class AdapterZaSpinner extends ArrayAdapter<Kategorija> {

    public AdapterZaSpinner(Context context, ArrayList<Kategorija> kategorije) {
        super(context, 0, kategorije);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.element_spinnera, parent, false
            );
        }

        TextView kategorija = convertView.findViewById(R.id.kategorijaUSpineru);
        ImageView slikaKategorije = convertView.findViewById(R.id.slikaKategorije);

        Kategorija currentItem = getItem(position);

        if (currentItem != null) {
            kategorija.setText(currentItem.getNaziv());
        }

        return convertView;
    }
}

