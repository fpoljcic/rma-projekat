package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import org.apache.commons.codec.Encoder;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;


public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {

    EditText imeKategorije, idKategorije;
    Button dodajIkonu, dodajKategoriju;
    private Icon[] ikone;
    IconDialog iconDialog;
    ArrayList<Kategorija> kategories;
    private boolean postojiLiUBazi = false;
    Kategorija novaKategorija;
    String TOKEN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);
        new DajToken().execute("proba");

        iconDialog = new IconDialog();
        imeKategorije = (EditText) findViewById(R.id.etNaziv);
        idKategorije = (EditText) findViewById(R.id.etIkona);
        dodajIkonu = (Button) findViewById(R.id.btnDodajIkonu);
        dodajKategoriju = (Button) findViewById(R.id.btnDodajKategoriju);

        Intent primi = getIntent();
        kategories = primi.getParcelableArrayListExtra("kategory");


        dodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imeKategorije.getText().toString().equals("")) {
                    Toast.makeText(getApplicationContext(), "Unesite ime kategorije", Toast.LENGTH_SHORT).show();
                    imeKategorije.setBackgroundColor(Color.RED);
                } else if (idKategorije.getText().toString().equals("")) {
                    idKategorije.setBackgroundColor(Color.RED);
                    Toast.makeText(getApplicationContext(), "Izaberite ikonu", Toast.LENGTH_SHORT).show();
                } else {
                    novaKategorija = new Kategorija(imeKategorije.getText().toString(), idKategorije.getText().toString());
                    boolean kategorijaVecPostoji = false;

                    for (Kategorija i : kategories) {
                        if (i.getNaziv().equalsIgnoreCase(novaKategorija.getNaziv())) {
                            kategorijaVecPostoji = true;
                        }
                    }

                    new PostojiLiKategorija().execute("Kategorije", novaKategorija.getNaziv());


                    if (kategorijaVecPostoji) {
                        Toast.makeText(getApplicationContext(), "Kategorija pod tim imenom vec postoji!", Toast.LENGTH_SHORT).show();
                        imeKategorije.setBackgroundColor(Color.RED);
                        return;
                    }
                }
            }
        });

        dodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(ikone);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        ikone = icons;
        if (icons.length != 0)
            idKategorije.setText(Integer.toString(icons[0].getId()));
    }

    @Override
    public void onBackPressed() {
        Intent vratiBroj = new Intent(getApplicationContext(), DodajKvizAkt.class);
        vratiBroj.putExtra("nazad", 1);
        setResult(RESULT_OK, vratiBroj);
        finish();

    }

    private class DajToken extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential googleCredential;
            try {
                InputStream tajna = getResources().openRawResource(R.raw.secret);
                googleCredential = GoogleCredential.fromStream(tajna).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));

                googleCredential.refreshToken();
                TOKEN = googleCredential.getAccessToken();
                Log.d("TOKEN", TOKEN);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    private class PostojiLiKategorija extends AsyncTask<String, Integer, Integer> {

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            if (integer == 1) {
                Intent intent = new Intent(getApplicationContext(), DodajKvizAkt.class);
                intent.putExtra("novaKategorija", novaKategorija);
                setResult(RESULT_OK, intent);
                finish();
            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(DodajKategorijuAkt.this).create();
                alertDialog.setTitle("Greska");
                alertDialog.setMessage("Kategorija pod tim imenom vec postoji!");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                alertDialog.show();
            }
        }

        protected Integer doInBackground(String... urls) {
            try {
                String url1;
                if (urls.length == 1)
                    url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "?access_token=" + TOKEN;
                else
                    url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=" + TOKEN;
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                return 1;
            }
            return 0;
        }
    }
}
