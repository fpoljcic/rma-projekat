package ba.unsa.etf.rma.tasks;


import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.net.ssl.HttpsURLConnection;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangItem;
import ba.unsa.etf.rma.klase.RangLista;

public class FireService extends IntentService {
    public static final int RANGLISTA = 13;
    private String token;

    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = -1;
    public static final int KATEGORIJE = 10;
    public static final int KVIZOVI = 11;
    public static final int PITANJA = 12;


    public FireService(){
        super(null);
    }
    public FireService(String name) {
        super(name);
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        final ResultReceiver receiver = intent.getParcelableExtra("receiver");
        Bundle bundle = new Bundle();
        receiver.send(STATUS_RUNNING, Bundle.EMPTY);
        getAccessToken();
        bundle.putString("name","json");
        bundle.putString("token",token);
        String name = intent.getStringExtra("name");
        String method = intent.getStringExtra("method");
//        getRangListe("");
        switch (name){
            case "Kategorije":
                if(method.equals("GET")) {
                    getPitanja("");
                    String kategorijeJSON = getKategorije("");
                    bundle.putString("json", kategorijeJSON);
                    bundle.putParcelableArrayList("kategorije", Creator.kategorijeFromJSON(kategorijeJSON));
                    receiver.send(KATEGORIJE, bundle);
                }else if(method.equals("ADD")){
                    Kategorija kategorija = (Kategorija) intent.getExtras().getSerializable("kategorija");
                    try {
                        addKategorija(kategorija);
                        receiver.send(STATUS_FINISHED,Bundle.EMPTY);
                    } catch (Exception e) {
                        bundle.putString("error",e.getMessage());
                        receiver.send(STATUS_ERROR,bundle);
                    }
                }
                break;
            case "Kvizovi":
                switch(method){
                    case "GET":
                        String kvizoviJSON = getKvizovi(intent.getStringExtra("filter"));
                        String kategorijaJSON = getKategorije(intent.getStringExtra("filter"));
                        String pitanjaJSON = getPitanja("");
                        ArrayList<Pitanje> pitanja = Creator.pitanjaFromJSON(pitanjaJSON);
                        bundle.putString("json", kvizoviJSON);
                        bundle.putParcelableArrayList("kvizovi",Creator.kvizoviFromJSON(kvizoviJSON,kategorijaJSON,pitanja));
                        receiver.send(KVIZOVI,bundle);
                        break;
                    case "ADD":
                        try {
                            addKviz((Kviz) intent.getExtras().getSerializable("kviz"));
                            receiver.send(STATUS_FINISHED,Bundle.EMPTY);
                        }catch(IllegalArgumentException e){
                            bundle.putString("error",e.getMessage());
                            receiver.send(STATUS_ERROR,bundle);
                        }
                        break;
                    case "EDIT":
                        try{
                            editKviz((Kviz) intent.getExtras().getSerializable("oldKviz"), (Kviz) intent.getExtras().getSerializable("kviz"));
                            receiver.send(STATUS_FINISHED,Bundle.EMPTY);
                        }catch(IllegalArgumentException e){
                            bundle.putString("error",e.getMessage());
                            receiver.send(STATUS_ERROR,bundle);
                        }
                        break;
                }
                break;
            case "Pitanja":
                switch(method){
                    case "GET":
                        Kviz kviz = (Kviz) intent.getExtras().getSerializable("kviz");
                        ArrayList<Pitanje> pitanja = Creator.pitanjaFromJSON(getPitanja(""));
                        if(kviz!=null){
                            for(int i=0;i<pitanja.size();i++){
                                if(kviz.getPitanja().contains(pitanja.get(i))){
                                    pitanja.remove(pitanja.get(i));
                                    i--;
                                }
                            }
                        }
                        bundle.putParcelableArrayList("pitanja",pitanja);
                        receiver.send(PITANJA,bundle);
                        break;
                    case "ADD":
                        Pitanje pitanje = (Pitanje) intent.getExtras().getSerializable("pitanje");

                        try{
                            addPitanje(pitanje);
                            receiver.send(STATUS_FINISHED,Bundle.EMPTY);
                        }catch (IllegalArgumentException e){
                            bundle.putString("error",e.getMessage());
                            receiver.send(STATUS_ERROR,bundle);
                        }
                        break;
                }
                break;
            case "Ranglista":
                switch(method){
                    case "GET":
                        String nazivKviza = intent.getStringExtra("kviz");
                        String rangListe = getRangListe(nazivKviza);
                        System.out.println(rangListe);
                        ArrayList<RangLista> rangList = Creator.rangListafromJSON(rangListe);
                        bundle.putSerializable("Ranglista",rangList);
                        receiver.send(RANGLISTA,bundle);
                        break;
                    case "ADD":
                        nazivKviza = intent.getStringExtra("kviz");
                        String user = intent.getStringExtra("user");
                        double userResult = intent.getDoubleExtra("userResult",0);
                        rangListe = getRangListe(nazivKviza);
                        String id = getIDFromRangLista(rangListe);
                        rangList = Creator.rangListafromJSON(rangListe);
                        if (rangList.isEmpty()) {
                            rangList.add(new RangLista(nazivKviza));
                        }
                        rangList.get(0).addRangItem(new RangItem(user, userResult));
                        if(id.equals("")){
                            try{
                                createRangList(rangList.get(0));

                            }catch (Exception e){
                                bundle.putString("error",e.getMessage());
                                receiver.send(STATUS_ERROR,bundle);
                            }
                        }else{
                            updateRangList(id,rangList.get(0));
                        }
                        break;
                }
                break;
        }
    }

    private void updateRangList(String id, RangLista rangLista) {
        String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents/Rangliste/"+id+"?currentDocument.exists=true&access_token="+token;
        String rangListJSON = Creator.rangListaToJSON(rangLista);
        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
            con.setRequestMethod("PATCH");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);


            try(OutputStream os = con.getOutputStream()) {
                byte[] input = rangListJSON.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            System.out.println(con.getResponseMessage());
            System.out.println(con.getResponseCode());

            if(con.getResponseCode()!=200){
                throw new IllegalArgumentException("Conflict");
            }
        } catch (IOException e) {

            System.out.println(e.getMessage());
        }
    }

    private void createRangList(RangLista rangLista) {
        String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents/Rangliste?&access_token="+token;
        String rangListaJSON = Creator.rangListaToJSON(rangLista);
        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = rangListaJSON.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            if(con.getResponseCode()!=200){
                throw new IllegalArgumentException("Conflict POST Ranglista");
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    private String getIDFromRangLista(String rangListe) {
        try {
            JSONArray documents = new JSONArray(rangListe);
            for (int i = 0; i < documents.length();i++) {
                JSONObject document = documents.getJSONObject(i).getJSONObject("document");
                String id = document.getString("name");
                String[] tokens = id.split("/");
                id = tokens[tokens.length-1];
                return id;
            }
        } catch (JSONException e) {
            System.out.println("There is no rang list. It will be created now!");
        }
        return "";
    }

    private String getKvizovi(String filter){
        String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents:runQuery?access_token="+token;

        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);

            String jsonQuery = "{" +
                    "  \"structuredQuery\": " +
                    "  {" +
                    "    \"from\": " +
                    "    [" +
                    "      {" +
                    "        \"collectionId\": \"Kvizovi\"" +
                    "      }" +
                    "    ]" +
                    (!((filter.equals("Svi")||(filter.equals(""))))?"" +
                            "," +
                            "    \"where\": " +
                            "    {" +
                            "      \"fieldFilter\": " +
                            "      {" +
                            "        \"field\": " +
                            "        {" +
                            "          \"fieldPath\": \"idKategorije\"" +
                            "        }," +
                            "        \"op\": \"EQUAL\"," +
                            "        \"value\": " +
                            "        {" +
                            "          \"stringValue\": \""+filter+"\"" +
                            "        }" +
                            "      }" +
                            "    }"
                            :"")+
                    "  }" +
                    "}";

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonQuery.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder responseResult = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    responseResult.append(responseLine.trim());
                }
                return responseResult.toString();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return "{}";
    }

    private String getKategorije(String filter){
        String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents:runQuery?access_token="+token;

        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            // optional default is GET
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);
            String jsonQuery = "{" +
                    "  \"structuredQuery\": " +
                    "  {" +
                    "    \"from\": " +
                    "    [" +
                    "      {" +
                    "        \"collectionId\": \"Kategorije\"" +
                    "      }" +
                    "    ]" +
                    ((!(filter.equals("Svi")|| filter.equals("")))?"" +
                            ", " +
                            "    \"where\": " +
                            "    {" +
                            "      \"fieldFilter\": " +
                            "      {" +
                            "        \"field\": " +
                            "        {" +
                            "          \"fieldPath\": \"naziv\"" +
                            "        }," +
                            "        \"op\": \"EQUAL\"," +
                            "        \"value\": " +
                            "        {" +
                            "          \"stringValue\": \""+filter+"\"" +
                            "        }" +
                            "      }" +
                            "    }"
                            :"")+
                    "  }" +
                    "}";

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonQuery.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder responseResult = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    responseResult.append(responseLine.trim());
                }
                return responseResult.toString();
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return "{}";
    }

    public String getPitanja(String filter){
        String url ="https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents:runQuery?access_token="+token;
        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            // optional default is GET
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);
            String jsonQuery = "{" +
                    "  \"structuredQuery\": " +
                    "  {" +
                    "    \"from\": " +
                    "    [" +
                    "      {" +
                    "        \"collectionId\": \"Pitanja\"" +
                    "      }" +
                    "    ]" +
                    ((!(filter.equals("")))?"" +
                            ", " +
                            "    \"where\": " +
                            "    {" +
                            "      \"fieldFilter\": " +
                            "      {" +
                            "        \"field\": " +
                            "        {" +
                            "          \"fieldPath\": \"naziv\"" +
                            "        }," +
                            "        \"op\": \"EQUAL\"," +
                            "        \"value\": " +
                            "        {" +
                            "          \"stringValue\": \""+filter+"\"" +
                            "        }" +
                            "      }" +
                            "    }"
                            :"")+
                    "  }" +
                    "}";

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonQuery.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder responseResult = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    responseResult.append(responseLine.trim());
                }
                return responseResult.toString();
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return "{}";
    }
    public String getRangListe(String imeKviza){
    String url ="https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents:runQuery?access_token="+token;
        try {
        URL obj = new URL(url);
        HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

        // optional default is GET
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setRequestProperty("Accept", "application/json");
        con.setDoOutput(true);
        String jsonQuery = "{" +
                "  \"structuredQuery\": " +
                "  {" +
                "    \"from\": " +
                "    [" +
                "      {" +
                "        \"collectionId\": \"Rangliste\"" +
                "      }" +
                "    ]" +
                ((!(imeKviza.equals("")))?"" +
                        ", " +
                        "    \"where\": " +
                        "    {" +
                        "      \"fieldFilter\": " +
                        "      {" +
                        "        \"field\": " +
                        "        {" +
                        "          \"fieldPath\": \"nazivKviza\"" +
                        "        }," +
                        "        \"op\": \"EQUAL\"," +
                        "        \"value\": " +
                        "        {" +
                        "          \"stringValue\": \""+imeKviza+"\"" +
                        "        }" +
                        "      }" +
                        "    }"
                        :"")+
                "  }" +
                "}";

        try(OutputStream os = con.getOutputStream()) {
            byte[] input = jsonQuery.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        try(BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "utf-8"))) {
            StringBuilder responseResult = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                responseResult.append(responseLine.trim());
            }

            return responseResult.toString();
        }

    } catch (IOException e) {
        System.out.println(e.getMessage());
    }

        return "{}";
}

    private void getAccessToken() {
        InputStream inputStream = getResources().openRawResource(R.raw.secret);
        try {
            GoogleCredential credentials = GoogleCredential.fromStream(inputStream).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();
            token = credentials.getAccessToken();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }


    public void editKviz(Kviz oldKviz, Kviz kviz){
        String kvizID = getKvizIDByName(oldKviz.getNaziv());
        String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents/Kvizovi/"+kvizID+"?currentDocument.exists=true&access_token="+token;
        String pitanja = "";
        for(int i=0;i<kviz.getPitanja().size();i++){
            pitanja +="          {" +
                    "            \"stringValue\": \""+kviz.getPitanja().get(i).getNaziv()+"\"" +
                    "          }";
            if(i!=kviz.getPitanja().size()-1)pitanja+=", ";
        }
        String kvizJSON = "{" +

                "  \"fields\": " +
                "  {" +
                "    \"idKategorije\": " +
                "    {" +
                "      \"stringValue\": \""+kviz.getKategorija().getNaziv()+"\"" +
                "    }," +
                "    \"naziv\": " +
                "    {" +
                "      \"stringValue\": \""+kviz.getNaziv()+"\"" +
                "    }," +
                "    \"pitanja\": " +
                "    {" +
                "      \"arrayValue\": " +
                "      {" +
                "        \"values\": " +
                "        [" +
                pitanja +
                "        ]" +
                "      }" +
                "    }" +
                "  }" +
                "}";
        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
            con.setRequestMethod("PATCH");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);


            try(OutputStream os = con.getOutputStream()) {
                byte[] input = kvizJSON.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            if(con.getResponseCode()!=200){
                throw new IllegalArgumentException("Conflict");
            }
        } catch (IOException e) {

            System.out.println(e.getMessage());
        }

    }

    private String getKvizIDByName(String naziv) {
        String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents:runQuery?access_token="+token;

        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);

            String jsonQuery = "{\n" +
                    "  \"structuredQuery\": \n" +
                    "  {\n" +
                    "    \"where\": \n" +
                    "    {\n" +
                    "      \"fieldFilter\": \n" +
                    "      {\n" +
                    "        \"field\": \n" +
                    "        {\n" +
                    "          \"fieldPath\": \"naziv\"\n" +
                    "        },\n" +
                    "        \"op\": \"EQUAL\",\n" +
                    "        \"value\": \n" +
                    "        {\n" +
                    "          \"stringValue\": \""+naziv+"\"\n" +
                    "        }\n" +
                    "      }\n" +
                    "    },\n" +
                    "    \"from\": \n" +
                    "    [\n" +
                    "      {\n" +
                    "        \"collectionId\": \"Kvizovi\"\n" +
                    "      }\n" +
                    "    ],\n" +
                    "    \"select\": \n" +
                    "    {\n" +
                    "      \"fields\": \n" +
                    "      [\n" +
                    "        {\n" +
                    "          \"fieldPath\": \"name\"\n" +
                    "        }\n" +
                    "      ]\n" +
                    "    }\n" +
                    "  }\n" +
                    "}";

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonQuery.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder responseResult = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    responseResult.append(responseLine.trim());
                }

                String[] urlParts = new String[0];
                try {
                    JSONArray responseObject = new JSONArray(responseResult.toString());
                    urlParts = responseObject.getJSONObject(0).getJSONObject("document").getString("name").split("/");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return urlParts[urlParts.length-1];
            }

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        return "";

    }



    public void addKviz(Kviz kviz){
        String jsonKviz = getKvizovi(kviz.getKategorija().getNaziv());
        ArrayList<Kviz> kvizovi = Creator.kvizoviFromJSON(jsonKviz,getKategorije(kviz.getKategorija().getNaziv()),kviz.getPitanja());
        if (kvizovi.isEmpty() || !kvizovi.contains(kviz)) {
            String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents/Kvizovi?&access_token="+token;
            String pitanja = "";
            for(int i=0;i<kviz.getPitanja().size();i++){
                pitanja +="          {" +
                        "            \"stringValue\": \""+kviz.getPitanja().get(i).getNaziv()+"\"" +
                        "          }";
                if(i!=kviz.getPitanja().size()-1)pitanja+=", ";
            }
            String kvizJSON = "{" +

                            "  \"fields\": " +
                            "  {" +
                            "    \"idKategorije\": " +
                            "    {" +
                            "      \"stringValue\": \""+kviz.getKategorija().getNaziv()+"\"" +
                            "    }," +
                            "    \"naziv\": " +
                            "    {" +
                            "      \"stringValue\": \""+kviz.getNaziv()+"\"" +
                            "    }," +
                            "    \"pitanja\": " +
                            "    {" +
                            "      \"arrayValue\": " +
                            "      {" +
                            "        \"values\": " +
                            "        [" +
                                            pitanja +
                            "        ]" +
                            "      }" +
                            "    }" +
                            "  }" +
                            "}";
            try {
                URL obj = new URL(url);
                HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);


                try(OutputStream os = con.getOutputStream()) {
                    byte[] input = kvizJSON.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                if(con.getResponseCode()!=200){
                    throw new IllegalArgumentException("Conflict POST Kviz");
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        } else {
            throw new IllegalArgumentException("Kviz already exists!");
        }
    }


    public void addKategorija(Kategorija kategorija){
        String jsonKategorije = getKategorije(kategorija.getNaziv());
        ArrayList<Kategorija> kategorijas = Creator.kategorijeFromJSON(jsonKategorije);
        if (kategorijas.isEmpty()) {
            String url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents/Kategorije?access_token=" + token;
            try {
                URL obj = new URL(url);
                HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);
                String kategorijaJSON = "{\n" +
                        "  \"fields\": \n" +
                        "  {\n" +
                        "    \"naziv\": \n" +
                        "    {\n" +
                        "      \"stringValue\": \"" + kategorija.getNaziv() + "\"\n" +
                        "    },\n" +
                        "    \"idIkonice\": \n" +
                        "    {\n" +
                        "      \"integerValue\": \"" + kategorija.getId() + "\"\n" +
                        "    }\n" +
                        "  }\n" +
                        "}";

                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = kategorijaJSON.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                if (con.getResponseCode() != 200) {
                    throw new IllegalArgumentException("conflict");
                }
            } catch (IOException e) {

                System.out.println(e.getMessage());
            }
        } else {
            throw new IllegalArgumentException("Kategorija already exists");
        }
    }

    public void addPitanje(Pitanje pitanje){


        String jsonPitanje = getPitanja(pitanje.getNaziv());
        ArrayList<Pitanje> pitanja = Creator.pitanjaFromJSON(jsonPitanje);

        if (pitanja.isEmpty()) {
            String url = null;
            try {
                url = "https://firestore.googleapis.com/v1/projects/rmaspirala18252/databases/(default)/documents/Pitanja?access_token="+URLEncoder.encode(token,"UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            String odgovori = "";
            for(int i=0;i<pitanje.getOdgovori().size();i++){
                odgovori +="          {" +
                        "            \"stringValue\": \""+pitanje.getOdgovori().get(i)+"\"" +
                        "          }";
                if(i!=pitanje.getOdgovori().size()-1)odgovori+=", ";
            }
            String pitanjeJSON = "{" +
                    "  \"fields\": " +
                    "  {" +
                    "    \"naziv\": " +
                    "    {" +
                    "      \"stringValue\": \""+pitanje.getNaziv().replace("?","\\?")+"\"" +
                    "    }," +
                    "    \"indexTacnog\": " +
                    "    {" +
                    "      \"integerValue\":\""+pitanje.getOdgovori().indexOf(pitanje.getTacan())+"\"" +
                    "    }," +
                    "    \"odgovori\": " +
                    "    {" +
                    "      \"arrayValue\": " +
                    "      {" +
                    "        \"values\": " +
                    "        [" +
                    odgovori +
                    "        ]" +
                    "      }" +
                    "    }" +
                    "  }" +
                    "}";
            try {
                URL obj = new URL(url);
                HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setRequestProperty("Accept", "application/json");
                con.setDoOutput(true);


                try(OutputStream os = con.getOutputStream()) {
                    byte[] input = pitanjeJSON.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = con.getResponseCode();
                if(code!=200){
                    throw new IllegalArgumentException("Conflict");
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }

        }else{
            throw new IllegalArgumentException("Pitanje already exists");
        }

    }
}
