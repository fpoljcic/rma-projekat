package ba.unsa.etf.rma.fragmenti;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.RangListaAdapter;
import ba.unsa.etf.rma.klase.RangItem;
import ba.unsa.etf.rma.klase.RangLista;


public class RangListaFragment extends Fragment {

    private ArrayList<RangItem> items;
    private RangLista rangLista;

    private RangListaAdapter adapter;
    private ListView scoreBoard;



    public RangListaFragment() {
        // Required empty public constructor
    }

    public static RangListaFragment newInstance(RangLista rangLista) {
        RangListaFragment fragment = new RangListaFragment();
        Bundle args = new Bundle();
        args.putSerializable("RangLista",rangLista);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            rangLista = (RangLista) getArguments().getSerializable("RangLista");

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ranglista_list, container, false);
        scoreBoard = view.findViewById(R.id.scores);
        items = new ArrayList<>();
        items.addAll(rangLista.getLista());
        adapter = new RangListaAdapter(getContext(),R.layout.fragment_ranglista,items);
        scoreBoard.setAdapter(adapter);
        return view;
    }

}
