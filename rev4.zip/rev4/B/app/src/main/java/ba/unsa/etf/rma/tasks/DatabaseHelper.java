package ba.unsa.etf.rma.tasks;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangItem;
import ba.unsa.etf.rma.klase.RangLista;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "storage.db";
    public static final String TABELA_KATEGORIJE = "kategorije";
    public static final String TABELA_KVIZOVI = "kvizovi";
    public static final String TABELA_PITANJA = "pitanja";
    public static final String TABELA_ODGOVORI = "odgovori";
//    public static final String TABELA_RANGLISTE = "rangliste";
    public static final String TABELA_PITANJA_KVIZOVI = "pitanjaKvizovi";
    public static final String TABELA_RANG_ITEMS = "rangItems";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+TABELA_KATEGORIJE+"(" +
                "ID integer primary key autoincrement," +
                "naziv text," +
                "idKategorije text)");
        db.execSQL("create table "+TABELA_ODGOVORI+" (" +
                "ID integer primary key autoincrement," +
                "odgovor text," +
                "tacan integer," +
                "odgovorIndex integer," +
                "pitanje text)");
        db.execSQL("create table "+TABELA_PITANJA+"(" +
                "ID integer primary key autoincrement," +
                "naziv text" +
                ")");
        db.execSQL("create table "+TABELA_KVIZOVI+"(" +
                "ID integer primary key autoincrement," +
                "naziv text," +
                "kategorija text)");
        db.execSQL("create table "+TABELA_PITANJA_KVIZOVI+"(" +
                "ID integer primary key autoincrement," +
                "pitanje text," +
                "kviz text)");
//        db.execSQL("create table "+TABELA_RANGLISTE+"(" +
//                "ID integer primary key autoincrement," +
//                "nazivKviza text)");
        db.execSQL("create table "+TABELA_RANG_ITEMS+"(" +
                "ID integer primary key autoincrement," +
                "user text," +
                "userScore real," +
                "kviz text," +
                "origin text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists "+TABELA_KATEGORIJE);
        db.execSQL("drop table if exists "+TABELA_KVIZOVI);
        db.execSQL("drop table if exists "+TABELA_PITANJA);
        db.execSQL("drop table if exists "+TABELA_PITANJA_KVIZOVI);
        db.execSQL("drop table if exists "+TABELA_RANG_ITEMS);
        db.execSQL("drop table if exists "+TABELA_ODGOVORI);
        onCreate(db);

    }

    public boolean updateDatabase(ArrayList<Kviz> kvizovi, ArrayList<Kategorija> kategorije,
                                  ArrayList<Pitanje> pitanja, ArrayList<RangLista> rangListas){
        ArrayList<RangLista> local = getLocalScores();
        for (RangLista localRangLista : local) {
            for (int i = 0; i < rangListas.size();i++) {
                if(rangListas.get(i).getKviz().equals(localRangLista.getKviz())){
                    for (RangItem rangItem : localRangLista.getLista()) {
                        rangListas.get(i).addRangItem(rangItem);
                    }
                }
            }
        }
        updateRangListe(rangListas);
        insertOrUpdateKvizovi(kvizovi);
        insertKategorije(kategorije);
        insertPitanja(pitanja);
        joinKvizoviPitanja(kvizovi);
        return true;
    }

    private boolean joinKvizoviPitanja(ArrayList<Kviz> kvizovi){
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABELA_PITANJA_KVIZOVI,null,null);
        for (Kviz kviz : kvizovi) {
            for (Pitanje pitanje : kviz.getPitanja()) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("pitanje", pitanje.getNaziv());
                contentValues.put("kviz", kviz.getNaziv());
                database.insert(TABELA_PITANJA_KVIZOVI, null, contentValues);
            }
        }
        return true;
    }

    private boolean insertPitanja(ArrayList<Pitanje> pitanja){
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABELA_PITANJA,null,null);
        database.delete(TABELA_ODGOVORI,null,null);
        for (Pitanje pitanje : pitanja) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("naziv", pitanje.getNaziv());
            database.insert(TABELA_PITANJA, null, contentValues);
        }
        for (Pitanje pitanje : pitanja) {
            for (String odgovor : pitanje.getOdgovori()){
                ContentValues contentValues = new ContentValues();
                contentValues.put("odgovor", odgovor);
                int tacan = 0;
                if(odgovor.equals(pitanje.getTacan()))tacan = 1;
                contentValues.put("tacan", tacan);
                contentValues.put("pitanje", pitanje.getNaziv());
                contentValues.put("indexOdgovora",pitanje.getOdgovori().indexOf(odgovor));
                database.insert(TABELA_ODGOVORI, null, contentValues);
            }
        }
        return true;
    }

    private boolean insertKategorije(ArrayList<Kategorija> kategorijas){
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABELA_KATEGORIJE,null,null);
        for(Kategorija kategorija : kategorijas){
                ContentValues contentValues = new ContentValues();
                contentValues.put("naziv",kategorija.getNaziv());
                contentValues.put("idKategorije", kategorija.getId());
                database.insert(TABELA_KATEGORIJE, null, contentValues);
        }
        return true;
    }

    private boolean insertOrUpdateKvizovi(ArrayList<Kviz> kvizovi) {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABELA_KVIZOVI,null,null);
        database.delete(TABELA_PITANJA_KVIZOVI, null, null);
        for(Kviz kviz : kvizovi){
            ContentValues contentValues = new ContentValues();
            contentValues.put("naziv",kviz.getNaziv());
            contentValues.put("kategorija", kviz.getKategorija().getNaziv());
            database.insert(TABELA_KATEGORIJE, null, contentValues);
            for (Pitanje pitanje : kviz.getPitanja()) {
                ContentValues contentValues1 = new ContentValues();
                contentValues1.put("pitanje", pitanje.getNaziv());
                contentValues1.put("kviz", kviz.getNaziv());
                database.insert(TABELA_PITANJA_KVIZOVI, null, contentValues1);
            }
        }
        return true;
    }

    private boolean updateRangListe(ArrayList<RangLista> rangListas) {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABELA_RANG_ITEMS,null,null);
        for(RangLista rangLista : rangListas){
            for(RangItem rangItem: rangLista.getLista()){
                ContentValues contentValues = new ContentValues();
                contentValues.put("user",rangItem.getUser());
                contentValues.put("userScore", rangItem.getResult());
                contentValues.put("kviz", rangLista.getKviz());
                contentValues.put("origin", "online");
                database.insert(TABELA_KATEGORIJE, null, contentValues);
            }
        }
        return true;
    }

    public boolean addRangItem(RangItem rangItem, String nazivKviza) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("user", rangItem.getUser());
        contentValues.put("userScore", rangItem.getResult());
        contentValues.put("kviz", nazivKviza);
        contentValues.put("origin","offline");
        database.insert(TABELA_RANG_ITEMS, null, contentValues);
        return true;
    }

    private ArrayList<RangLista> getLocalScores() {
        return getScores("origin=offline");
    }

    public ArrayList<RangLista> getScores(String selection){
        ArrayList<RangLista> rangListas = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.query(TABELA_RANG_ITEMS, null, selection, null, "kviz", null, null);
        if(cursor.getCount()!=0){
            cursor.moveToFirst();
            do {
                String user = cursor.getString(2);
                Double userScore = cursor.getDouble(3);
                RangItem rangItem = new RangItem(user, userScore);
                String nazivKviza = cursor.getString(4);
                if (!rangListas.isEmpty()) {
                    boolean found = false;
                    for (int i = 0; i < rangListas.size(); i++) {
                        if (rangListas.get(i).getKviz().equals(nazivKviza)) {
                            found = true;
                            rangListas.get(i).addRangItem(rangItem);
                        }
                    }
                    if (!found) {
                        RangLista rangLista = new RangLista(nazivKviza);
                        rangLista.addRangItem(rangItem);
                        rangListas.add(rangLista);
                    }
                }else{
                    RangLista rangLista = new RangLista(nazivKviza);
                    rangLista.addRangItem(rangItem);
                    rangListas.add(rangLista);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return rangListas;
    }

    public ArrayList<Kategorija> getKategorije(){
        ArrayList<Kategorija> kategorijas = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.query(TABELA_KATEGORIJE, null, null, null, null, null, null);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                Kategorija kategorija = new Kategorija();
                kategorija.setNaziv(cursor.getString(2));
                kategorija.setId(cursor.getString(3));
                kategorijas.add(kategorija);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return kategorijas;
    }

    public ArrayList<Pitanje> getPitanja(){
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.query(TABELA_PITANJA, null, null, null, null, null, null);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                Pitanje pitanje = new Pitanje();
                pitanje.setNaziv(cursor.getString(2));
                pitanje.setTekstPitanja(cursor.getString(2));
                pitanja.add(pitanje);
            } while (cursor.moveToNext());
        }
        cursor.close();
        cursor = database.query(TABELA_ODGOVORI, null, null, null, null, null, null);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String odgovor = cursor.getString(2);
                int tacan = cursor.getInt(3);
                String pitanje = cursor.getString(5);
                for (int i = 0; i < pitanja.size(); i++) {
                    if (pitanja.get(i).getNaziv().equals(pitanje)) {
                        pitanja.get(i).getOdgovori().add(odgovor);
                        if(tacan == 1){
                            pitanja.get(i).setTacan(odgovor);
                        }
                    }
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        return pitanja;
    }

    public ArrayList<Kviz> getKvizovi(){
        ArrayList<Kviz> kvizovi = new ArrayList<>();
        ArrayList<Pitanje> pitanja = getPitanja();
        ArrayList<Kategorija> kategorijas = getKategorije();
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.query(TABELA_KVIZOVI, null, null, null, null, null, null);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                String nazivKviza = cursor.getString(2);
                String nazivKategorije = cursor.getString(3);
                Kviz kviz = new Kviz();
                kviz.setNaziv(nazivKviza);
                for (Kategorija kategorija : kategorijas) {
                    if (kategorija.getNaziv().equals(nazivKategorije)) {
                        kviz.setKategorija(kategorija);
                    }
                }
                Cursor cursor1 = database.query(TABELA_PITANJA_KVIZOVI, null, "kviz=", new String[]{kviz.getNaziv()}, null, null, null);
                if (cursor1.getCount() != 0) {
                    cursor1.moveToFirst();
                    do {
                        String nazivPitanja = cursor1.getString(3);
                        for (Pitanje pitanje : pitanja) {
                            if (pitanje.getNaziv().equals(nazivPitanja)) {
                                kviz.dodajNovoPitanje(pitanje);
                            }
                        }
                    } while (cursor1.moveToNext());
                }
                cursor1.close();
                kvizovi.add(kviz);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return kvizovi;
    }



}
