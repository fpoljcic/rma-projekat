package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;


public class ListaFrag extends Fragment {

    private ArrayList<Kategorija> kategorije;

    private OnFragmentInteractionListener mListener;

    private ListView listaKategorija;

    private ArrayAdapter<Kategorija> kategorijaAdapter;

    public ListaFrag() {
        // Required empty public constructor
    }

    public static ListaFrag newInstance(ArrayList<Kategorija> kategorije) {
        ListaFrag fragment = new ListaFrag();
        Bundle args = new Bundle();
        args.putSerializable("kategorije",kategorije);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            kategorije = (ArrayList<Kategorija>) getArguments().getSerializable("kategorije");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_lista, container, false);
        listaKategorija = view.findViewById(R.id.listaKategorija);
//        kategorije = new ArrayList<>();
//        kategorije.add(new Kategorija("Svi", null));
//        kategorije.addAll(DataAccessLayer.getInstance().getKategorije());
        kategorijaAdapter = new ArrayAdapter<>(getContext(),android.R.layout.simple_list_item_1,kategorije);
        listaKategorija.setAdapter(kategorijaAdapter);
        listaKategorija.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mListener.filterSelection(kategorije.get(position));
            }
        });
        return view;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {


        void filterSelection(Kategorija kategorija);
    }
}
