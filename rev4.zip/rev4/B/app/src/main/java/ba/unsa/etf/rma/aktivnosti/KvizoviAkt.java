package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.CalendarEventProvider;
import ba.unsa.etf.rma.MyResultReceiver;
import ba.unsa.etf.rma.NetworkChangeReceiver;
import ba.unsa.etf.rma.adapteri.KvizoviAdapter;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.tasks.FireService;

public class KvizoviAkt extends FragmentActivity implements DetailFrag.OnFragmentInteractionListener,
                                                            ListaFrag.OnFragmentInteractionListener, MyResultReceiver.Receiver,
        NetworkChangeReceiver.Receiver {

    private static boolean active =false;
    private Spinner spPostojeceKategorije;
    private ListView lvKvizovi;
    private ArrayList<Kviz> kvizovi=null;
    private KvizoviAdapter kvizoviAdapter=null;
    private ArrayAdapter<Kategorija> spinnerAdapter;
    private ArrayList<Kategorija> kategorije;
    private DetailFrag detailFragment;
    private ListaFrag listaFragment;
    private MyResultReceiver myResultReceiver;
    public boolean isConnected;
    private NetworkChangeReceiver myNetworkChangeReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        active =true;
        allowAccessToThreads();
        isConnected = false;

        myResultReceiver = new MyResultReceiver(new Handler());
        myResultReceiver.setReceiver(this);
        myNetworkChangeReceiver = new NetworkChangeReceiver();
        myNetworkChangeReceiver.setMyReceiver(this);
        IntentFilter intentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        this.registerReceiver(myNetworkChangeReceiver,intentFilter);

        init();

        if (getScreenWidth() >= 550) {
            setContentView(R.layout.wide_activity_kvizovi_akt);
            detailFragment = DetailFrag.newInstance(kvizovi);
            listaFragment = ListaFrag.newInstance(kategorije);
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.listPlace, listaFragment);
            fragmentTransaction.add(R.id.detailPlace, detailFragment);
            fragmentTransaction.commit();
        } else {
            setContentView(R.layout.activity_kvizovi_akt);
            spPostojeceKategorije = findViewById(R.id.spPostojeceKategorije);
            lvKvizovi = findViewById(R.id.lvKvizovi);
            initNarrowLayout();
        }
        getKvizoviFromService("Svi");
        getKategorijeFromService();
    }




    private void allowAccessToThreads() {
        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
    }

    private void init() {
        kategorije = new ArrayList<>();
        kvizovi = new ArrayList<>();
    }

    private void initNarrowLayout() {
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPostojeceKategorije.setAdapter(spinnerAdapter);
        kvizoviAdapter = new KvizoviAdapter(this,R.layout.kviz_cell,kvizovi);
        lvKvizovi.setAdapter(kvizoviAdapter);
        lvKvizovi.setOnItemClickListener((parent, view, position, id) -> {
            if (position == kvizovi.size() - 1) {
//                    Intent dodajKviz = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
//                    dodajKviz.putExtra("index", -1);
//                    startActivityForResult(dodajKviz, 1);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
                        if (shouldShowRequestPermissionRationale(Manifest.permission.READ_CALENDAR)) {
                            Toast.makeText(this, "Allow usage of calendar!", Toast.LENGTH_LONG).show();
                        }
                        requestPermissions(new String[]{Manifest.permission.READ_CALENDAR},0);
                    }else{

                    }
                }
                long time = (CalendarEventProvider.nextEvent(this));
                Date date = new Date(time);
                Date now = new Date();

                if(now.before(date) && date.getTime()-now.getTime()<kvizovi.get(position).getPitanja().size()*500*60){
                    Toast.makeText(this, "Imaš event uskoro!", Toast.LENGTH_SHORT).show();
                }else{
                    playKvizAtPosition(position);
                }

            }
        });
        lvKvizovi.setOnItemLongClickListener((parent, view, position, id) -> {
            if(isConnected)addOrEditKviz(position);
            return false;
        }
        );
        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                kvizovi.clear();
                getKvizoviFromService(((Kategorija)parent.getSelectedItem()).getNaziv());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void playKvizAtPosition(int position) {
        Intent igrajKviz = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("kviz",kvizovi.get(position));
        igrajKviz.putExtras(bundle);
        startActivityForResult(igrajKviz,69);
    }

    private void addOrEditKviz(int position) {
        Intent dodajKviz = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
        if (position == kvizovi.size() - 1) {
            dodajKviz.putExtra("index", -1);
        } else {
            dodajKviz.putExtra("index", position);
            Bundle bundle = new Bundle();
            bundle.putSerializable("kviz", kvizovi.get(position));
            dodajKviz.putExtras(bundle);
        }
        startActivityForResult(dodajKviz, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        getKategorijeFromService();
        kvizovi.clear();
        String filter;
        if(getScreenWidth()<550){
            filter=((Kategorija) spPostojeceKategorije.getSelectedItem()).getNaziv();
        }else{
            filter="Svi";
        }
        getKvizoviFromService(filter);
        active =true;
    }

    private void refreshKvizHolder(){
        if (getScreenWidth() < 550) {
            kvizoviAdapter.notifyDataSetChanged();
        } else {
            constructWideLayout();
        }
    }
    private void refreshContentHolders() {
        if (getScreenWidth() < 550) {
            spinnerAdapter.notifyDataSetChanged();
            spPostojeceKategorije.setSelection(0);
            kvizoviAdapter.notifyDataSetChanged();
        } else {
            constructWideLayout();
        }
    }

    private void constructWideLayout() {
        detailFragment = DetailFrag.newInstance(kvizovi);
        listaFragment = ListaFrag.newInstance(kategorije);
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.listPlace, listaFragment);
        fragmentTransaction.replace(R.id.detailPlace, detailFragment);
        fragmentTransaction.commit();
    }

    private float getScreenWidth(){
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics ();
        display.getMetrics(outMetrics);

        float density  = getResources().getDisplayMetrics().density;
        float dpWidth  = outMetrics.widthPixels / density;

        return dpWidth;
    }

    @Override
    public void playKviz(Kviz kviz) {
        playKvizAtPosition(kvizovi.indexOf(kviz));
    }

    @Override
    public void addKviz() {
        addOrEditKviz(kvizovi.size()-1);
    }

    @Override
    public void editKviz(Kviz kviz) {
        addOrEditKviz(kvizovi.indexOf(kviz));
    }


    @Override
    public void filterSelection(Kategorija kategorija) {
        kvizovi.clear();
        getKvizoviFromService(kategorija.getNaziv());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        active =false;
    }

    private void getKvizoviFromService(String filter){
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Kvizovi");
        intent.putExtra("method","GET");
        intent.putExtra("filter",filter);
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }

    private void getKategorijeFromService(){
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Kategorije");
        intent.putExtra("method","GET");
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }

    @Override
    public void onRecieveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case FireService.KATEGORIJE:
                kategorije.clear();
                kategorije.add(new Kategorija("Svi", ""));
                kategorije.addAll(resultData.getParcelableArrayList("kategorije"));
                refreshContentHolders();
                break;
            case FireService.PITANJA:
                break;
            case FireService.KVIZOVI:
                kvizovi.clear();
                kvizovi.addAll(resultData.getParcelableArrayList("kvizovi"));
                kvizovi.add(new Kviz("Dodaj kviz", null, new Kategorija("add", String.valueOf(android.R.drawable.btn_plus))));
                System.out.println(kvizovi);
                refreshKvizHolder();
                break;
            case FireService.STATUS_ERROR:

                break;
            case FireService.STATUS_FINISHED:
                break;
            case FireService.STATUS_RUNNING:
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(myNetworkChangeReceiver);

    }

    @Override
    public void onReceive(boolean connected) {
        if(!isConnected && connected)updateDatabase();
        isConnected = connected;
        if (connected) {
            Toast.makeText(this, "Connected!", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(this,"Dissconnected!",Toast.LENGTH_SHORT).show();
        }
    }

    private void updateDatabase() {

    }
}
