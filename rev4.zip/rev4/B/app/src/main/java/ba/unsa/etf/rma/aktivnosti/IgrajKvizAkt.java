package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.AlarmClock;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.MyResultReceiver;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.fragmenti.RangListaFragment;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.klase.RangItem;
import ba.unsa.etf.rma.klase.RangLista;
import ba.unsa.etf.rma.tasks.FireService;

public class IgrajKvizAkt extends FragmentActivity
                                implements InformacijeFrag.OnFragmentInteractionListener
                                , PitanjeFrag.OnFragmentInteractionListener,
                                 MyResultReceiver.Receiver{

    private Kviz kviz;
    private InformacijeFrag informacijeFragment;
    private PitanjeFrag pitanjeFragment;
    private RangListaFragment rangListaFragment;
    private RangLista rangLista;
    private ArrayList<Pitanje> pitanja;
    private Pitanje trenutnoPitanje=null;
    private MyResultReceiver myResultReceiver;
    private boolean ready;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);
        myResultReceiver = new MyResultReceiver(new Handler());
        myResultReceiver.setReceiver(this);
        ready = false;

        kviz = (Kviz) getIntent().getExtras().getSerializable("kviz");
        startAlarmClock(kviz.getPitanja().size());
        pitanja = new ArrayList<>();
        if(kviz.getPitanja()!=null)pitanja.addAll(kviz.getPitanja());
        try {
            useNextRandomPitanje();
        } catch (Exception e) {
            ArrayList<String> odgovori = new ArrayList<>();
            Pitanje pitanje = new Pitanje("Kviz je završen!","Kviz je završen!",odgovori,"");
            trenutnoPitanje = pitanje;
        }
        rangLista = new RangLista();
        rangLista.setKviz(kviz.getNaziv());
        getRangListaFromService();

        informacijeFragment = InformacijeFrag.newInstance(kviz);
        pitanjeFragment = PitanjeFrag.newInstance(trenutnoPitanje);
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.informacijePlace, informacijeFragment);
        fragmentTransaction.add(R.id.pitanjePlace, pitanjeFragment);
        fragmentTransaction.commit();


    }

    private void startAlarmClock(int minutes) {
        Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
        Date date = new Date();
        int delta = (int) (minutes / 2.0 + date.getMinutes() + ((date.getSeconds() > 0) ? 1.0 : 0.0));

        intent.putExtra(AlarmClock.EXTRA_HOUR, date.getHours()+delta/60);
        intent.putExtra(AlarmClock.EXTRA_MINUTES, delta%60);
        intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        System.out.println(minutes/2.0 + date.getMinutes() + ((date.getSeconds() > 0) ? 1.0 : 0.0));
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,"Permission denied!",Toast.LENGTH_SHORT).show();
        }
    }

    private void showRank(String user) {
        System.out.println(user);
        Double userResult = informacijeFragment.getResult();
        postEntryToService(user,userResult);
        rangLista.addRangItem(new RangItem(user,userResult));
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        System.out.println("show rank "+rangLista);
        rangListaFragment = RangListaFragment.newInstance(rangLista);
        fragmentTransaction.replace(R.id.pitanjePlace, rangListaFragment);
        fragmentTransaction.commit();
        ready = true;
    }


    private void useNextRandomPitanje() {
        Collections.shuffle(pitanja);
        trenutnoPitanje = pitanja.get(0);
        pitanja.remove(0);
    }

    @Override
    public void nextQuestion(Boolean answeredRight) {
        try {
            informacijeFragment.proceed(answeredRight);
            useNextRandomPitanje();
            final PitanjeFrag newPitanjeFragment = PitanjeFrag.newInstance(trenutnoPitanje);
            final Handler handler = new Handler();
            handler.postDelayed(() -> {
                //Do something after 2000ms
                try {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.pitanjePlace, newPitanjeFragment);
                    fragmentTransaction.commit();
                } catch (Exception e) {
                    finish();
                }
            }, 2000);
        } catch (Exception kvizFinished) {
;
            final Handler handler = new Handler();
            handler.postDelayed(() -> {
                //Do something after 2000ms
                try {
//                    Intent intent = new Intent(AlarmClock.ACTION_DISMISS_ALARM);
//                    intent.putExtra(AlarmClock.ALARM_SEARCH_MODE_NEXT,true);
//                    intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
//                    startActivity(intent);
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("Ime");
                    final EditText input = new EditText(this);
                    input.setInputType(InputType.TYPE_CLASS_TEXT );
                    builder.setView(input);
                    builder.setPositiveButton("OK", (dialog, which) -> showRank(input.getText().toString()));
                    builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
                    builder.show();
                } catch (Exception e) {
                    finish();
                }
            }, 2000);
        }
    }

    private void getRangListaFromService() {

        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Ranglista");
        intent.putExtra("method","GET");
        intent.putExtra("receiver", myResultReceiver);
        intent.putExtra("kviz", kviz.getNaziv());
        startService(intent);
    }

    private void postEntryToService(String user, Double userResult) {
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Ranglista");
        intent.putExtra("method","ADD");
        intent.putExtra("receiver", myResultReceiver);
        intent.putExtra("kviz", kviz.getNaziv());
        intent.putExtra("user", user);
        intent.putExtra("userResult", userResult);
        startService(intent);
    }

    @Override
    public void endGame() {
//        Intent intent = new Intent(AlarmClock.ACTION_DISMISS_ALARM);
//        intent.putExtra(AlarmClock.ALARM_SEARCH_MODE_NEXT,true);
//        intent.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
//        startActivity(intent);
        Intent intent = new Intent(IgrajKvizAkt.this, KvizoviAkt.class);
        setResult(RESULT_OK, intent);
        finish();
    }


    @Override
    public void onRecieveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case FireService.STATUS_ERROR:
                break;
            case FireService.STATUS_FINISHED:
                break;
            case FireService.STATUS_RUNNING:
                break;
            case FireService.RANGLISTA:
                ArrayList<RangLista> rangListas = (ArrayList<RangLista>) resultData.getSerializable("Ranglista");
                if(rangListas!=null && !rangListas.isEmpty()){
                    rangLista.getLista().clear();
                    for (RangItem element : rangListas.get(0).getLista()) {
                        rangLista.addRangItem(element);
                    }
                    System.out.println(".."+rangListas.get(0));
                }
                break;
        }
    }
}
