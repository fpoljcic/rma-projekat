package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjaAdapter extends ArrayAdapter<Pitanje> {
    private int resource;
    public PitanjaAdapter( Context context, int resource,  List<Pitanje> objects) {
        super(context, resource,  objects);
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LinearLayout view=null;
        if(convertView==null){
            view = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li;
            li = (LayoutInflater)getContext().
                    getSystemService(inflater);
            li.inflate(resource, view, true);
        }else{
            view = (LinearLayout) convertView;
        }

        Pitanje pitanje = getItem(position);
        TextView text = view.findViewById(R.id.kvizText);
        ImageView ikona = view.findViewById(R.id.kvizIcon);

        text.setText(pitanje.getTekstPitanja());

        if (pitanje.getTekstPitanja().equals("Dodaj Pitanje")) {
            ikona.setImageResource(android.R.drawable.ic_menu_add);
        } else {
            ikona.setImageResource(android.R.drawable.btn_radio);
        }

        return view;

    }
}
