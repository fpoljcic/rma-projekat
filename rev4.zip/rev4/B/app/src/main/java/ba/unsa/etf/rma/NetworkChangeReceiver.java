package ba.unsa.etf.rma;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class NetworkChangeReceiver extends BroadcastReceiver {
    public Receiver myReceiver;

    public NetworkChangeReceiver(){

    }

    public void setMyReceiver(Receiver receiver) {
        myReceiver = receiver;
    }

    @Override
    public void onReceive(final Context context, final Intent intent) {

        int status = NetworkUtil.getConnectivityStatusString(context);
        Log.e("Sulod network reciever", "Sulod sa network reciever");
        if ("android.net.conn.CONNECTIVITY_CHANGE".equals(intent.getAction())) {
            if (status == NetworkUtil.NETWORK_STATUS_NOT_CONNECTED) {
                myReceiver.onReceive(false);
            } else {
                myReceiver.onReceive(true);
            }
        }
    }

    public interface Receiver {
        void onReceive(boolean connected);
    }
}
