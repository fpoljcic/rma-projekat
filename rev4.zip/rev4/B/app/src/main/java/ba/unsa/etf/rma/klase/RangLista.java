package ba.unsa.etf.rma.klase;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class RangLista implements Serializable {
    private String kviz;
    private Set<RangItem> lista;

    public RangLista() {
        lista = new TreeSet<>();
    }

    public RangLista(String kviz){
        this.kviz = kviz;
        lista = new TreeSet<>();
    }

    public String getKviz() {
        return kviz;
    }

    public void setKviz(String kviz) {
        this.kviz = kviz;
    }

    public Set<RangItem> getLista() {
        return lista;
    }

    public void setLista(Set<RangItem> lista) {
        this.lista = lista;
    }

    public void addRangItem(RangItem item){
        lista.add(item);
    }

    @Override
    public String toString() {
        String result = lista.size()+" "+kviz+":\n";
        ;
        for(Iterator<RangItem> it = lista.iterator();it.hasNext();){
            RangItem item = it.next();
            result += "\t"+" "+item.toString()+"\n";
        }

        return result;
    }
}
