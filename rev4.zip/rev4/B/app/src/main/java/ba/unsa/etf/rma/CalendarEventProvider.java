package ba.unsa.etf.rma;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import java.util.Date;

public class CalendarEventProvider {
    public static String[] PROJECTION = new String[]{
            CalendarContract.Events._ID,
            CalendarContract.Events.DTSTART
    };
    public static final int PROJECTION_START = 1;

    public static long nextEvent(Context context){
        ContentResolver contentResolver = context.getContentResolver();
        Uri uri = CalendarContract.Events.CONTENT_URI;
        String sortingOrder = CalendarContract.Events.DTSTART + " ASC";
        String selection = "(" + CalendarContract.Events.DTSTART + " >= ?)";
        String[] selectionArguments = new String[]{String.valueOf(new Date().getTime())};
        Cursor cursor = contentResolver.query(uri, PROJECTION, selection, selectionArguments, sortingOrder);

        if (cursor == null || cursor.getCount() == 0) {
            return -1;
        }
        cursor.moveToFirst();
        long result = cursor.getLong(PROJECTION_START);
        cursor.close();

        return result;
    }

}
