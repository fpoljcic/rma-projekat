package ba.unsa.etf.rma.aktivnosti;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.DataAccessLayer;
import ba.unsa.etf.rma.MyResultReceiver;
import ba.unsa.etf.rma.adapteri.PitanjaAdapter;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.tasks.FireService;

public class DodajKvizAkt extends AppCompatActivity implements MyResultReceiver.Receiver {

    private static final int READ_REQUEST_CODE = 42;
    private Spinner spKategorije;
    private ArrayAdapter<Kategorija> spinnerAdapter;
    private ArrayList<Kategorija> kategorije=null;
    private EditText etNaziv;
    private ListView lvDodanaPitanja;
    private ArrayList<Pitanje> pitanja=null;
    private ListView lvMogucaPitanja;
    private ArrayList<Pitanje> mogucaPitanja=null;
    private Button btnDodajKviz;
    private Button btnImportKviz;
    private PitanjaAdapter dodanaAdapter;
    private PitanjaAdapter mogucaAdapter;
    private Boolean editing;
    private Kviz trenutniKviz;
    private Drawable editTextBackground;
    private MyResultReceiver myResultReceiver;
    private String oldName;
    private Kviz oldKviz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        find();
        int index = getIntent().getIntExtra("index",-1);
        editing = index != -1;
        DataAccessLayer dal = DataAccessLayer.getInstance();
        myResultReceiver = new MyResultReceiver(new Handler());
        myResultReceiver.setReceiver(this);
        initKategorije();

        mogucaPitanja = new ArrayList<>();
        pitanja = new ArrayList<>();

        adapterSetup();
        getKategorijeFromService();
        if (editing) {
            trenutniKviz = (Kviz) getIntent().getExtras().getSerializable("kviz");
            pitanja.addAll(trenutniKviz.getPitanja());
            etNaziv.setText(trenutniKviz.getNaziv());
            spKategorije.setSelection(kategorije.indexOf(trenutniKviz.getKategorija()));
            oldName = trenutniKviz.getNaziv();
            oldKviz = trenutniKviz;
        }
        getMogucaPitanjaFromService(trenutniKviz);

        setupListeners();


    }


    private void setupListeners() {
        etNaziv.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!etNaziv.getText().equals("")) {
                    etNaziv.setBackground(editTextBackground);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnImportKviz.setOnClickListener(v -> performFileSearch());

        lvDodanaPitanja.setOnItemClickListener((parent, view, position, id) -> {
            if(position==pitanja.size()-1){
                Intent intent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);
                startActivityForResult(intent,2);
            }else{
                mogucaPitanja.add(pitanja.get(position));
                pitanja.remove(position);
                mogucaAdapter.notifyDataSetChanged();
                dodanaAdapter.notifyDataSetChanged();
            }
        });
        lvMogucaPitanja.setOnItemClickListener((parent, view, position, id) -> {
            pitanja.add(pitanja.size()-1,mogucaPitanja.get(position));
            mogucaPitanja.remove(position);
            mogucaAdapter.notifyDataSetChanged();
            dodanaAdapter.notifyDataSetChanged();
        });

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==kategorije.size()-1){
                    Intent dodavanjeKategorije = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);
                    startActivityForResult(dodavanjeKategorije,1);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        btnDodajKviz.setOnClickListener(v -> {
                //&& !((Kategorija) spKategorije.getSelectedItem()).getNaziv().equals("Svi")
            if (!etNaziv.getText().toString().equals("") ){
                Kategorija kategorija = new Kategorija();
                Kategorija item = (Kategorija) spKategorije.getSelectedItem();
                kategorija.setNaziv(item.getNaziv());
                kategorija.setId(item.getId());
                ArrayList<Pitanje> temp = new ArrayList<>(pitanja);
                temp.remove(pitanja.size()-1);
                Kviz kviz = new Kviz(etNaziv.getText().toString(), temp, kategorija);
                try {
                    if (editing) {
                        editKviz(kviz);
                    }else{
                        addKviz(kviz);
                    }

                } catch (Exception ignored) {

                }
            }else{
                etNaziv.setBackgroundColor(Color.RED);
            }
        });
    }


    private void adapterSetup() {
        dodanaAdapter = new PitanjaAdapter(this, R.layout.kviz_cell, pitanja);
        mogucaAdapter = new PitanjaAdapter(this, R.layout.kviz_cell, mogucaPitanja);
        spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kategorije);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spKategorije.setAdapter(spinnerAdapter);
        lvDodanaPitanja.setAdapter(dodanaAdapter);
        lvMogucaPitanja.setAdapter(mogucaAdapter);
    }

    private void initKategorije() {
        kategorije = new ArrayList<>();
        getKategorijeFromService();
    }

    private void find() {
        spKategorije= findViewById(R.id.spKategorije);
        etNaziv = findViewById(R.id.etNaziv);
        btnDodajKviz = findViewById(R.id.btnDodajKviz);
        lvDodanaPitanja = findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = findViewById(R.id.lvMogucaPitanja);
        btnImportKviz = findViewById(R.id.btnImportKviz);
        editTextBackground = etNaziv.getBackground();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {

            if (requestCode == 1) {
                refreshCategorySpinner();
                spKategorije.setSelection(kategorije.size() - 2);
            } else if (requestCode == 2) {
                Pitanje pitanje = (Pitanje) data.getExtras().getSerializable("pitanje");
                pitanja.add(pitanja.size() - 1, pitanje);
                dodanaAdapter.notifyDataSetChanged();
            } else if (requestCode == READ_REQUEST_CODE) {

                Uri uri = null;

                if (data != null) {
                    uri = data.getData();
                    try {
                        ParcelFileDescriptor pfd = DodajKvizAkt.this.getContentResolver().
                                openFileDescriptor(uri, "r");
                        FileInputStream fileInputStream =
                                new FileInputStream(pfd.getFileDescriptor());
                        String result = "";
                        int temp;
                        while ((temp = fileInputStream.read()) != -1) {
                            result += (char) temp;
                        }

                        try {
                            readKvizFile(result);
                        } catch (IllegalArgumentException reason) {

                        }
                        fileInputStream.close();
                        pfd.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }
            spKategorije.setSelection(kategorije.size() - 2);
        } else {
            spKategorije.setSelection(0);
        }


    }

    private void refreshCategorySpinner() {
        getKategorijeFromService();
    }

    private void readKvizFile(String kvizInfo) {
        try {
            boolean postojiKategorija=true;
            if(kvizInfo==null || kvizInfo.equals(""))throw new IllegalArgumentException("Prazno");

            String[] kvizInfoLines = new String[0];
            String nazivKviza = null;
            String nazivKategorijeKviza = null;
            String brojPitanjaKviza = null;
            try {
                kvizInfoLines = kvizInfo.split("\n");

                String[] nazivKategorijaBrojPitanja = kvizInfoLines[0].split(",");

                nazivKviza = nazivKategorijaBrojPitanja[0];
                nazivKategorijeKviza = nazivKategorijaBrojPitanja[1];
                brojPitanjaKviza = nazivKategorijaBrojPitanja[2];
            } catch (Exception e) {
                throw new IllegalArgumentException("Datoteka kviza kojeg importujete nema ispravan format!");
            }

            for (Kviz kviz : DataAccessLayer.getInstance().getKvizovi()) {
                if(kviz.getNaziv().equals(nazivKviza))
                    throw new IllegalArgumentException("Kviz kojeg importujete već postoji!");
            }

            Kviz importedKviz = new Kviz();
            importedKviz.setNaziv(nazivKviza);

            for (Kategorija kategorija : DataAccessLayer.getInstance().getKategorije(this)) {
                if (kategorija.getNaziv().equals(nazivKategorijeKviza)) {
                    importedKviz.setKategorija(kategorija);
                }
            }

            if (importedKviz.getKategorija() == null) {
                Kategorija importedKategorija = new Kategorija(nazivKategorijeKviza, String.valueOf(1));
                importedKviz.setKategorija(importedKategorija);
                DataAccessLayer.getInstance().dodajKategoriju(importedKviz.getKategorija());
            }
            refreshCategorySpinner();

            int brojPitanja = Integer.parseInt(brojPitanjaKviza);
            if (brojPitanja < 0 || kvizInfoLines.length <= brojPitanja) {
                throw new IllegalArgumentException("Kviz kojeg imporujete ima neispravan broj pitanja!");
            }

            for (int i = 1; i < brojPitanja + 1; i++) {
                Pitanje pitanje = readPitanje(kvizInfoLines[i]);
                if(i!=1 && importedKviz.getPitanja().contains(pitanje))throw new IllegalArgumentException("Kviz nije ispravan postoje dva pitanja sa istim nazivom!");
                importedKviz.dodajNovoPitanje(pitanje);
            }


            sendKvizInfoToView(importedKviz);
        } catch (IllegalArgumentException e) {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
            alertDialog.setMessage(e.getMessage());
            alertDialog.setCancelable(true);
            alertDialog.setPositiveButton("Ok",(dialog,id)->{
                dialog.cancel();
            });
            alertDialog.show();
        }


    }

    private void sendKvizInfoToView(Kviz importedKviz) {
        etNaziv.setText(importedKviz.getNaziv());

        pitanja.clear();
        pitanja.addAll(importedKviz.getPitanja());
        pitanja.add(new Pitanje("Dodaj Pitanje", "Dodaj Pitanje"));
        dodanaAdapter.notifyDataSetChanged();

        int indexOfKategorija = DataAccessLayer.getInstance().getKategorije(this).indexOf(importedKviz.getKategorija());
        spKategorije.setSelection(1+indexOfKategorija);


    }

    private Pitanje readPitanje(String pitanjeInfo) {
        //naziv(tekst pitanja),broj odgovora, indeks tacnog odgovora,odgovor0,odgovor1...
        String[] pitanjeInfoLines = pitanjeInfo.split(",");

        String nazivPitanja = pitanjeInfoLines[0];

        int brojOdgovora = Integer.parseInt(pitanjeInfoLines[1]);
        if (brojOdgovora < 1 || pitanjeInfoLines.length!=brojOdgovora+3) {
            throw new IllegalArgumentException("Kviz kojeg imporujete ima neispravan broj odgovora!"+nazivPitanja+String.valueOf(brojOdgovora));
        }

        int indexTacnogOdgovora = Integer.parseInt(pitanjeInfoLines[2]);
        if (indexTacnogOdgovora < 0 || indexTacnogOdgovora >= brojOdgovora) {
            throw new IllegalArgumentException("Kviz kojeg imporujete ima neispravan index tačnog odgovora!");
        }

        Pitanje importedPitanje = new Pitanje();
        importedPitanje.setNaziv(nazivPitanja);
        importedPitanje.setTekstPitanja(nazivPitanja);

        ArrayList<String> odgovori = new ArrayList<>(Arrays.asList(pitanjeInfoLines).subList(3, pitanjeInfoLines.length));
        for (int i = 0; i < odgovori.size(); i++) {
            for (int j = i + 1; j < odgovori.size(); j++) {
                if (odgovori.get(i).equals(odgovori.get(j))) {
                    throw new IllegalArgumentException("Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!");
                }
            }
        }
        importedPitanje.setOdgovori(odgovori);
        importedPitanje.setTacan(odgovori.get(indexTacnogOdgovora));
        return importedPitanje;
    }


    public void performFileSearch() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

        intent.addCategory(Intent.CATEGORY_OPENABLE);

        intent.setType("*/*");
        String[] mimeTypes = {"text/plain","text/csv","text/comma-seperated-values"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES,mimeTypes);
        startActivityForResult(intent, READ_REQUEST_CODE);
    }


    private void getKategorijeFromService(){
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Kategorije");
        intent.putExtra("method","GET");
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }

    private void getMogucaPitanjaFromService(Kviz trenutniKviz) {
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Pitanja");
        intent.putExtra("method","GET");
        Bundle bundle = new Bundle();
        bundle.putSerializable("kviz",trenutniKviz);
        intent.putExtras(bundle);
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }

    @Override
    public void onRecieveResult(int resultCode, Bundle resultData) {
        switch (resultCode) {
            case FireService.KATEGORIJE:
                kategorije.clear();
                kategorije.add(new Kategorija("Svi", String.valueOf(android.R.drawable.btn_radio)));
                kategorije.addAll(resultData.getParcelableArrayList("kategorije"));
                kategorije.add(new Kategorija("Dodaj kategoriju", String.valueOf(android.R.drawable.btn_plus)));
                spinnerAdapter.notifyDataSetChanged();
                if(editing){
                    spKategorije.setSelection(kategorije.indexOf(trenutniKviz.getKategorija()));
                }
                break;
            case FireService.PITANJA:
                mogucaPitanja.clear();
                mogucaPitanja.addAll(resultData.getParcelableArrayList("pitanja"));
                pitanja.add(new Pitanje("Dodaj Pitanje", "Dodaj Pitanje", null, null));
                dodanaAdapter.notifyDataSetChanged();
                mogucaAdapter.notifyDataSetChanged();
                break;
            case FireService.KVIZOVI:
                break;
            case FireService.STATUS_ERROR:
                System.out.println("error");
                Toast.makeText(this, resultData.getString("error"), Toast.LENGTH_SHORT).show();
                break;
            case FireService.STATUS_FINISHED:
                Intent intent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                setResult(RESULT_OK, intent);
                finish();
                break;
            case FireService.STATUS_RUNNING:
                break;
        }
    }
    private void addKviz(Kviz kviz) {
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Kvizovi");
        intent.putExtra("method","ADD");
        Bundle bundle = new Bundle();
        bundle.putSerializable("kviz",kviz);
        intent.putExtras(bundle);
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }

    private void editKviz(Kviz kviz) {
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Kvizovi");
        intent.putExtra("method","EDIT");
        Bundle bundle = new Bundle();
        bundle.putSerializable("kviz",kviz);
        System.out.println("++++++++++++"+kviz);
        bundle.putSerializable("oldKviz",oldKviz);
        intent.putExtras(bundle);
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }
}
